declare module '@glimmer/runtime/lib/dom/operations' {
    import type { Bounds, Dict, Nullable, SimpleComment, SimpleDocument, SimpleElement, SimpleNode, SimpleParentNode, SimpleText } from "@glimmer/interfaces";
    export const BLACKLIST_TABLE: Dict<1>;
    export class DOMOperations {
        protected document: SimpleDocument;
        protected uselessElement: SimpleElement;
        constructor(document: SimpleDocument);
        protected setupUselessElement(): void;
        createElement(tag: string, context?: SimpleParentNode): SimpleElement;
        insertBefore(parent: SimpleParentNode, node: SimpleNode, reference: Nullable<SimpleNode>): void;
        insertHTMLBefore(parent: SimpleParentNode, nextSibling: Nullable<SimpleNode>, html: string): Bounds;
        createTextNode(text: string): SimpleText;
        createComment(data: string): SimpleComment;
    }
    export function isElement(node: SimpleParentNode): node is SimpleElement;
    export function moveNodesBefore(
        source: SimpleNode,
        target: SimpleParentNode,
        nextSibling: Nullable<SimpleNode>
    ): Bounds;
}