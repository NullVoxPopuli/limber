declare module '@glimmer/runtime/lib/bounds' {
    import type { Bounds, Cursor, Nullable, SimpleNode, SimpleParentNode } from "@glimmer/interfaces";
    export class CursorImpl implements Cursor {
        element: SimpleParentNode;
        nextSibling: Nullable<SimpleNode>;
        constructor(element: SimpleParentNode, nextSibling: Nullable<SimpleNode>);
    }
    export type DestroyableBounds = Bounds;
    export class ConcreteBounds implements Bounds {
        parentNode: SimpleParentNode;
        private first;
        private last;
        constructor(parentNode: SimpleParentNode, first: SimpleNode, last: SimpleNode);
        parentElement(): SimpleParentNode;
        firstNode(): SimpleNode;
        lastNode(): SimpleNode;
    }
    export function move(bounds: Bounds, reference: Nullable<SimpleNode>): Nullable<SimpleNode>;
    export function clear(bounds: Bounds): Nullable<SimpleNode>;
}