declare module '@glimmer/interfaces/lib/dom/bounds' {
    import type { Nullable } from "@glimmer/interfaces/lib/core.js";
    import type { SimpleNode, SimpleParentNode } from "@glimmer/interfaces/lib/dom/simple.js";

    export interface Bounds {
      // Despite the name this can be a DocumentFragment, such as a ShadowRoot.
      parentElement(): SimpleParentNode;
      firstNode(): SimpleNode;
      lastNode(): SimpleNode;
    }

    export interface Cursor {
      readonly element: SimpleParentNode;
      readonly nextSibling: Nullable<SimpleNode>;
    }
}