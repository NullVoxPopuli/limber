declare module '@glimmer/runtime/lib/vm/render-result' {
    import type { AppendingBlock, Environment, RenderResult, SimpleElement, SimpleNode, UpdatingOpcode } from "@glimmer/interfaces";
    export default class RenderResultImpl implements RenderResult {
        env: Environment;
        private updating;
        private bounds;
        readonly drop: object;
        constructor(env: Environment, updating: UpdatingOpcode[], bounds: AppendingBlock, drop: object);
        rerender({ alwaysRevalidate }?: {
            alwaysRevalidate?: false;
        }): void;
        parentElement(): SimpleElement;
        firstNode(): SimpleNode;
        lastNode(): SimpleNode;
        handleException(): void;
    }
}