declare module '@ember/-internals/metal/lib/alias' {
    import type { ExtendedMethodDecorator } from "@ember/-internals/metal/lib/decorator";
    import type { StandardFieldDecorator } from "@ember/-internals/metal/lib/decorator-util";
    export type AliasDecorator = ExtendedMethodDecorator & PropertyDecorator & StandardFieldDecorator & AliasDecoratorImpl;
    export default function alias(altKey: string): AliasDecorator;
    class AliasDecoratorImpl extends Function {
        readOnly<T extends ExtendedMethodDecorator>(this: T): T;
        oneWay<T extends ExtendedMethodDecorator>(this: T): T;
        meta(this: ExtendedMethodDecorator, meta?: any): any;
    }
    export {};
}