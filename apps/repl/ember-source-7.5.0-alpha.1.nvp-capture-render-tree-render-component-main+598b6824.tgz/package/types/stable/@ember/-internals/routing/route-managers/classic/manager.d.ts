declare module '@ember/-internals/routing/route-managers/classic/manager' {
    /**
      Classic Route Manager. Encapsulates Ember's existing classic `Route`
      behaviour behind the `RouteManager` API.
    */
    import type { default as Owner } from "@ember/-internals/owner";
    import type { InternalRouteInfo, RouteInfo, Transition } from "router_js";
    import type { ClassicDidEnterState, ClassicDidExitState, ClassicEnterState, ClassicExitState, ClassicWillEnterState, ClassicWillExitState, CreateRouteArgs, RouteCapabilities, RouteManagerWithClassicInterop, RouteStateBucket } from "@ember/-internals/routing/route-managers/api";
    import type { QueryParamMeta } from "@ember/routing/route";
    import { ClassicRouteBucket } from "@ember/-internals/routing/route-managers/classic/bucket";
    export class ClassicRouteManager implements RouteManagerWithClassicInterop<ClassicRouteBucket> {
        #private;
        capabilities: RouteCapabilities;
        constructor(owner: Owner);
        createRoute(_factory: object, args: CreateRouteArgs): ClassicRouteBucket;
        isInaccessibleByURL(bucket: ClassicRouteBucket): boolean;
        getDestroyable(_bucket: ClassicRouteBucket): object | null;
        getRouteWrapper(): object;
        willEnter(bucket: ClassicRouteBucket, state: ClassicWillEnterState): void;
        enter(bucket: ClassicRouteBucket, state: ClassicEnterState): Promise<unknown>;
        didEnter(bucket: ClassicRouteBucket, state: ClassicDidEnterState): void;
        willExit(bucket: ClassicRouteBucket, state: ClassicWillExitState): void;
        exit(bucket: ClassicRouteBucket, state?: ClassicExitState): void;
        didExit(_bucket: ClassicRouteBucket, _state: ClassicDidExitState): void;
        getInvokable(bucket: ClassicRouteBucket): Promise<object>;
        qp(bucket: ClassicRouteBucket): QueryParamMeta;
        stashNames(bucket: ClassicRouteBucket, routeInfo: InternalRouteInfo, dynamicParent: InternalRouteInfo): void;
        serializeQueryParam(bucket: ClassicRouteBucket, value: unknown, urlKey: string, defaultValueType: string): unknown;
        deserializeQueryParam(bucket: ClassicRouteBucket, value: unknown, urlKey: string, defaultValueType: string): unknown;
        serializeContext(bucket: ClassicRouteBucket, routeInfo: InternalRouteInfo, value: unknown): Record<string, unknown> | undefined;
        queryParamsDidChange(bucket: ClassicRouteBucket, changed: {}, totalPresent: unknown, removed: {}): boolean | void;
        finalizeQueryParamChange(bucket: ClassicRouteBucket, params: Record<string, string | null | undefined>, finalParams: {}[], transition: Transition): boolean | void;
        getContext(bucket: ClassicRouteBucket, params: Record<string, unknown>, transition: Transition): unknown;
        redirect(bucket: ClassicRouteBucket, _routeInfo: RouteInfo, context: unknown, transition: Transition): void;
        invokeAction(bucket: ClassicRouteBucket, name: string, args: unknown[]): boolean | undefined;
        triggerLoadingEvent(bucket: ClassicRouteBucket, transition: Transition): void;
        triggerErrorEvent(_bucket: ClassicRouteBucket, transition: Transition, error: Error, originBucket: RouteStateBucket | undefined): void;
        handleLoadingEvent(bucket: ClassicRouteBucket, transition: Transition, originBucket: RouteStateBucket | undefined): void;
        handleErrorEvent(bucket: ClassicRouteBucket, transition: Transition, error: Error, originBucket: RouteStateBucket | undefined): boolean;
        getRouteInfoMetadata(bucket: ClassicRouteBucket): unknown;
    }
}