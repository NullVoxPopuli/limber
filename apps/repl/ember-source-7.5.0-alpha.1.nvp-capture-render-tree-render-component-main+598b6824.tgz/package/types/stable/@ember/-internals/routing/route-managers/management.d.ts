declare module '@ember/-internals/routing/route-managers/management' {
    import type { RouteManagement, RouteManager, RouteStateBucket } from "router_js";
    export function associateRouteManagement(route: object, manager: RouteManager, bucket: RouteStateBucket): void;
    export function getRouteManagement(route: object): RouteManagement | undefined;
}