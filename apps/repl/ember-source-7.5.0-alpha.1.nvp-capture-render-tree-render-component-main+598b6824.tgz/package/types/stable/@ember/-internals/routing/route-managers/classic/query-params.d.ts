declare module '@ember/-internals/routing/route-managers/classic/query-params' {
    /**
      Classic query-param event handling, lifted out of the classic `Route`'s
      `actions` hash so the logic lives behind the `RouteManager` boundary. The
      router reaches these via `ClassicRouteManager.queryParamsDidChange` and
      `ClassicRouteManager.finalizeQueryParamChange`, which forward to the
      functions below.
    */
    import type { Transition } from "router_js";
    import { ClassicRouteBucket } from "@ember/-internals/routing/route-managers/classic/bucket";
    export function copyDefaultValue<T>(value: T): T;
    /**
      Classic `queryParamsDidChange`. Triggers a model refresh when a changed query
      param opts into `refreshModel`. Returns `true` so the event keeps bubbling.
     */
    export function queryParamsDidChange(
     bucket: ClassicRouteBucket,
     changed: {},
     _totalPresent: unknown,
     removed: {}
    ): boolean;
    /**
      Classic `finalizeQueryParamChange`. Only the `application` route does the
      work: it reconciles every controller's query-param values with the URL and
      collects the final serialized params.
     */
    export function finalizeQueryParamChange(
     bucket: ClassicRouteBucket,
     params: Record<string, string | null | undefined>,
     finalParams: {}[],
     transition: Transition
    ): boolean | void;
}