declare module '@ember/-internals/routing/route-managers/classic/outlet-component' {
    class OutletComponent {
    }
    export const CLASSIC_OUTLET: OutletComponent;
    export {};
}