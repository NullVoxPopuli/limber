declare module '@ember/-internals/routing/route-managers/outlet-state' {
    import { type InternalRouteInfo } from "router_js";
    /**
     * What the outlet walk descends from.
     */
    export interface OutletParent {
        /**
         * Represents what, if any, should be rendered into the next {{outlet}} found
         * at this level.
         *
         * This used to be a dictionary of children outlets, including the {{outlet}}
         * "main" outlet any {{outlet "named"}} named outlets. Since named outlets
         * are not a thing anymore, this can now just be a single`child`.
         */
        outlets: {
            main: OutletState | undefined;
        };
    }
    /**
     * Represents one rendered instance of a route.
     * Maps to a `routeInfo`.
     */
    export class OutletState implements OutletParent {
        readonly manager: {
            getRouteWrapper(): object;
            getInvokable(bucket: object): Promise<object>;
        };
        readonly bucket: object;
        readonly routeInfo: InternalRouteInfo;
        context: unknown;
        invokable: object | undefined;
        readonly outlets: {
            main: OutletState | undefined;
        };
        get name(): string;
        constructor(manager: {
            getRouteWrapper(): object;
            getInvokable(bucket: object): Promise<object>;
        }, bucket: object, routeInfo: InternalRouteInfo);
    }
}