declare module 'router_js' {
    export { default } from "router_js/lib/router";
    export { default as InternalTransition, logAbort, STATE_SYMBOL, PARAMS_SYMBOL, QUERY_PARAMS_SYMBOL, } from "router_js/lib/transition";
    export type { PublicTransition as Transition } from "router_js/lib/transition";
    export { default as TransitionState, TransitionError } from "router_js/lib/transition-state";
    export { default as InternalRouteInfo, type RouteInfo, type RouteInfoWithAttributes, } from "router_js/lib/route-info";
    export { throwIfAborted } from "router_js/lib/transition-aborted-error";
    export { routeCapabilities, hasClassicInterop, invokableFor } from "router_js/lib/route-manager";
    export type { RouteManager, RouteManagerWithClassicInterop, RouteStateBucket, RouteManagement, RouteCapabilities, RouteCapabilitiesVersions, NavigationState, NavigationActions, AsyncNavigationState, ClassicInteropArgs, WillEnterState, EnterState, DidEnterState, WillExitState, ExitState, DidExitState, ClassicWillEnterState, ClassicEnterState, ClassicDidEnterState, ClassicWillExitState, ClassicExitState, ClassicDidExitState, CreateRouteArgs, } from "router_js/lib/route-manager";
}