declare module '@glimmer/compiler/lib/passes/2-encoding/mir' {
    import type { CurriedType, PresentArray } from "@glimmer/interfaces";
    import type * as ASTv2 from "@glimmer/syntax/lib/v2/api";
    import type { BlockSymbolTable, ProgramSymbolTable, SymbolTable } from "@glimmer/syntax/lib/symbol-table";
    import type { SourceSlice } from "@glimmer/syntax/lib/source/slice";
    import type { AnyOptionalList, OptionalList, PresentList } from "@glimmer/compiler/lib/shared/list";
    const Template_base: ASTv2.TypedNodeConstructor<"Template", {
        scope: ProgramSymbolTable;
        body: Statement[];
    } & ASTv2.BaseNodeFields>;
    export class Template extends Template_base {
    }
    const InElement_base: ASTv2.TypedNodeConstructor<"InElement", {
        guid: string;
        insertBefore: ExpressionNode | Missing;
        destination: ExpressionNode;
        block: NamedBlock;
    } & ASTv2.BaseNodeFields>;
    export class InElement extends InElement_base {
    }
    const Not_base: ASTv2.TypedNodeConstructor<"Not", {
        value: ExpressionNode;
    } & ASTv2.BaseNodeFields>;
    export class Not extends Not_base {
    }
    const If_base: ASTv2.TypedNodeConstructor<"If", {
        condition: ExpressionNode;
        block: NamedBlock;
        inverse: NamedBlock | null;
    } & ASTv2.BaseNodeFields>;
    export class If extends If_base {
    }
    const IfInline_base: ASTv2.TypedNodeConstructor<"IfInline", {
        condition: ExpressionNode;
        truthy: ExpressionNode;
        falsy: ExpressionNode | null;
    } & ASTv2.BaseNodeFields>;
    export class IfInline extends IfInline_base {
    }
    const Each_base: ASTv2.TypedNodeConstructor<"Each", {
        value: ExpressionNode;
        key: ExpressionNode | null;
        block: NamedBlock;
        inverse: NamedBlock | null;
    } & ASTv2.BaseNodeFields>;
    export class Each extends Each_base {
    }
    const Let_base: ASTv2.TypedNodeConstructor<"Let", {
        positional: Positional;
        block: NamedBlock;
    } & ASTv2.BaseNodeFields>;
    export class Let extends Let_base {
    }
    const WithDynamicVars_base: ASTv2.TypedNodeConstructor<"WithDynamicVars", {
        named: NamedArguments;
        block: NamedBlock;
    } & ASTv2.BaseNodeFields>;
    export class WithDynamicVars extends WithDynamicVars_base {
    }
    const GetDynamicVar_base: ASTv2.TypedNodeConstructor<"GetDynamicVar", {
        name: ExpressionNode;
    } & ASTv2.BaseNodeFields>;
    export class GetDynamicVar extends GetDynamicVar_base {
    }
    const Log_base: ASTv2.TypedNodeConstructor<"Log", {
        positional: Positional;
    } & ASTv2.BaseNodeFields>;
    export class Log extends Log_base {
    }
    const InvokeComponent_base: ASTv2.TypedNodeConstructor<"InvokeComponent", {
        definition: ExpressionNode;
        args: Args;
        blocks: NamedBlocks | null;
    } & ASTv2.BaseNodeFields>;
    export class InvokeComponent extends InvokeComponent_base {
    }
    const NamedBlocks_base: ASTv2.TypedNodeConstructor<"NamedBlocks", {
        blocks: OptionalList<NamedBlock>;
    } & ASTv2.BaseNodeFields>;
    export class NamedBlocks extends NamedBlocks_base {
    }
    const NamedBlock_base: ASTv2.TypedNodeConstructor<"NamedBlock", {
        scope: BlockSymbolTable;
        name: SourceSlice;
        body: Statement[];
    } & ASTv2.BaseNodeFields>;
    export class NamedBlock extends NamedBlock_base {
    }
    const AppendTrustedHTML_base: ASTv2.TypedNodeConstructor<"AppendTrustedHTML", {
        html: ExpressionNode;
    } & ASTv2.BaseNodeFields>;
    export class AppendTrustedHTML extends AppendTrustedHTML_base {
    }
    const AppendTextNode_base: ASTv2.TypedNodeConstructor<"AppendTextNode", {
        text: ExpressionNode;
    } & ASTv2.BaseNodeFields>;
    export class AppendTextNode extends AppendTextNode_base {
    }
    const AppendComment_base: ASTv2.TypedNodeConstructor<"AppendComment", {
        value: SourceSlice;
    } & ASTv2.BaseNodeFields>;
    export class AppendComment extends AppendComment_base {
    }
    const Component_base: ASTv2.TypedNodeConstructor<"Component", {
        tag: ExpressionNode;
        params: ElementParameters;
        args: NamedArguments;
        blocks: NamedBlocks;
    } & ASTv2.BaseNodeFields>;
    export class Component extends Component_base {
    }
    export interface AttrKind {
        trusting: boolean;
        component: boolean;
    }
    const StaticAttr_base: ASTv2.TypedNodeConstructor<"StaticAttr", {
        kind: {
            component: boolean;
        };
        name: SourceSlice;
        value: SourceSlice;
        namespace?: string | undefined;
    } & ASTv2.BaseNodeFields>;
    export class StaticAttr extends StaticAttr_base {
    }
    const DynamicAttr_base: ASTv2.TypedNodeConstructor<"DynamicAttr", {
        kind: AttrKind;
        name: SourceSlice;
        value: ExpressionNode;
        namespace?: string | undefined;
    } & ASTv2.BaseNodeFields>;
    export class DynamicAttr extends DynamicAttr_base {
    }
    const SimpleElement_base: ASTv2.TypedNodeConstructor<"SimpleElement", {
        tag: SourceSlice;
        params: ElementParameters;
        body: Statement[];
        dynamicFeatures: boolean;
    } & ASTv2.BaseNodeFields>;
    export class SimpleElement extends SimpleElement_base {
    }
    const ElementParameters_base: ASTv2.TypedNodeConstructor<"ElementParameters", {
        body: AnyOptionalList<ElementParameter>;
    } & ASTv2.BaseNodeFields>;
    export class ElementParameters extends ElementParameters_base {
    }
    const Yield_base: ASTv2.TypedNodeConstructor<"Yield", {
        target: SourceSlice;
        to: number;
        positional: Positional;
    } & ASTv2.BaseNodeFields>;
    export class Yield extends Yield_base {
    }
    const Debugger_base: ASTv2.TypedNodeConstructor<"Debugger", {
        scope: SymbolTable;
    } & ASTv2.BaseNodeFields>;
    export class Debugger extends Debugger_base {
    }
    const CallExpression_base: ASTv2.TypedNodeConstructor<"CallExpression", {
        callee: ExpressionNode;
        args: Args;
    } & ASTv2.BaseNodeFields>;
    export class CallExpression extends CallExpression_base {
    }
    const Modifier_base: ASTv2.TypedNodeConstructor<"Modifier", {
        callee: ExpressionNode;
        args: Args;
    } & ASTv2.BaseNodeFields>;
    export class Modifier extends Modifier_base {
    }
    const InvokeBlock_base: ASTv2.TypedNodeConstructor<"InvokeBlock", {
        head: ExpressionNode;
        args: Args;
        blocks: NamedBlocks;
    } & ASTv2.BaseNodeFields>;
    export class InvokeBlock extends InvokeBlock_base {
    }
    const SplatAttr_base: ASTv2.TypedNodeConstructor<"SplatAttr", {
        symbol: number;
    } & ASTv2.BaseNodeFields>;
    export class SplatAttr extends SplatAttr_base {
    }
    const PathExpression_base: ASTv2.TypedNodeConstructor<"PathExpression", {
        head: ExpressionNode;
        tail: Tail;
    } & ASTv2.BaseNodeFields>;
    export class PathExpression extends PathExpression_base {
    }
    const Missing_base: ASTv2.TypedNodeConstructor<"Missing", object & ASTv2.BaseNodeFields>;
    export class Missing extends Missing_base {
    }
    const InterpolateExpression_base: ASTv2.TypedNodeConstructor<"InterpolateExpression", {
        parts: PresentList<ExpressionNode>;
    } & ASTv2.BaseNodeFields>;
    export class InterpolateExpression extends InterpolateExpression_base {
    }
    const HasBlock_base: ASTv2.TypedNodeConstructor<"HasBlock", {
        target: SourceSlice;
        symbol: number;
    } & ASTv2.BaseNodeFields>;
    export class HasBlock extends HasBlock_base {
    }
    const HasBlockParams_base: ASTv2.TypedNodeConstructor<"HasBlockParams", {
        target: SourceSlice;
        symbol: number;
    } & ASTv2.BaseNodeFields>;
    export class HasBlockParams extends HasBlockParams_base {
    }
    const Curry_base: ASTv2.TypedNodeConstructor<"Curry", {
        definition: ExpressionNode;
        curriedType: CurriedType;
        args: Args;
    } & ASTv2.BaseNodeFields>;
    export class Curry extends Curry_base {
    }
    const Positional_base: ASTv2.TypedNodeConstructor<"Positional", {
        list: OptionalList<ExpressionNode>;
    } & ASTv2.BaseNodeFields>;
    export class Positional extends Positional_base {
    }
    const NamedArguments_base: ASTv2.TypedNodeConstructor<"NamedArguments", {
        entries: OptionalList<NamedArgument>;
    } & ASTv2.BaseNodeFields>;
    export class NamedArguments extends NamedArguments_base {
    }
    const NamedArgument_base: ASTv2.TypedNodeConstructor<"NamedArgument", {
        key: SourceSlice;
        value: ExpressionNode;
    } & ASTv2.BaseNodeFields>;
    export class NamedArgument extends NamedArgument_base {
    }
    const Args_base: ASTv2.TypedNodeConstructor<"Args", {
        positional: Positional;
        named: NamedArguments;
    } & ASTv2.BaseNodeFields>;
    export class Args extends Args_base {
    }
    const Tail_base: ASTv2.TypedNodeConstructor<"Tail", {
        members: PresentArray<SourceSlice>;
    } & ASTv2.BaseNodeFields>;
    export class Tail extends Tail_base {
    }
    export type ExpressionNode = ASTv2.LiteralExpression | ASTv2.KeywordExpression | ASTv2.VariableReference | Missing | PathExpression | InterpolateExpression | CallExpression | Not | IfInline | HasBlock | HasBlockParams | Curry | GetDynamicVar | Log;
    export type ElementParameter = StaticAttr | DynamicAttr | Modifier | SplatAttr;
    export type Internal = Args | Positional | NamedArguments | NamedArgument | Tail | NamedBlock | NamedBlocks | ElementParameters;
    export type ExprLike = ExpressionNode | Internal;
    export type Statement = InElement | Debugger | Yield | AppendTrustedHTML | AppendTextNode | Component | SimpleElement | InvokeBlock | AppendComment | If | Each | Let | WithDynamicVars | InvokeComponent;
    export {};
}