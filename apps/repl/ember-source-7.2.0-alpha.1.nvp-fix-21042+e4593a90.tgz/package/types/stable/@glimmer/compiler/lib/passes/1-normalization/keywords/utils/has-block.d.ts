declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/utils/has-block' {
    import * as ASTv2 from "@glimmer/syntax/lib/v2/api";
    import { SourceSlice } from "@glimmer/syntax/lib/source/slice";
    import type { KeywordDelegate } from "@glimmer/compiler/lib/passes/1-normalization/keywords/impl";
    import * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export function hasBlockKeyword(type: string): KeywordDelegate<ASTv2.CallExpression | ASTv2.AppendContent, SourceSlice, mir.HasBlock | mir.HasBlockParams>;
}