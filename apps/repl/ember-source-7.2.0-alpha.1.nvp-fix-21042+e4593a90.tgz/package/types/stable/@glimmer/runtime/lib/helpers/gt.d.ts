declare module '@glimmer/runtime/lib/helpers/gt' {
    /**
     * Performs a greater than comparison.
     *
     * left > right
     */
    export function gt<T>(left: T, right: T): boolean;
}