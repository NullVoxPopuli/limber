declare module '@glimmer/runtime/lib/references/class-list' {
    import type { Reference } from "@glimmer/reference/lib/reference";
    export default function createClassListRef(list: Reference[]): Reference<string | null>;
}