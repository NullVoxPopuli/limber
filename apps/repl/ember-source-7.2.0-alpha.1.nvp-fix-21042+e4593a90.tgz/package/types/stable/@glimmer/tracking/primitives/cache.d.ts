declare module '@glimmer/tracking/primitives/cache' {
    export { createCache, getValue, isConst } from "@glimmer/validator/lib/tracking";
}