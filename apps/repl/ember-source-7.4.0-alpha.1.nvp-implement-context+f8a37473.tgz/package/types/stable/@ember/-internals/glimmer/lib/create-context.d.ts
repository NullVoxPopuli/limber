declare module '@ember/-internals/glimmer/lib/create-context' {
    import { type OpaqueInternalComponentConstructor } from "@ember/-internals/glimmer/lib/components/internal";
    /**
     * The shape returned by `createContext`. Use `Provide` in templates to bind a
     * value into the render tree, read `value` to get the nearest enclosing
     * provided value, or call `consume(this)` to read it from a component
     * instance's position in the render tree (e.g. in an event handler).
     */
    export interface Context<T> {
        Provide: OpaqueInternalComponentConstructor;
        get value(): T;
        consume(consumer?: object): T;
    }
    /**
     * Creates a render-tree-scoped context per [RFC #1200][rfc].
     *
     * [rfc]: https://github.com/emberjs/rfcs/pull/1200
     *
     * `createContext` takes no value of its own -- it only establishes the
     * *type* of the value (via a type parameter) and returns a `Provide`
     * component plus a `value` getter. The value is supplied at render time
     * through `<Provide @value={{...}}>`.
     *
     * @example
     *
     * ```gjs
     * import { createContext } from '@ember/helper';
     *
     * class Theme {
     *   color = 'dark';
     * }
     *
     * const theme = createContext<Theme>();
     *
     * <template>
     *   <theme.Provide @value={{this.theme}}>
     *     {{theme.value.color}} {{! whatever this.theme.color is }}
     *   </theme.Provide>
     *
     *   {{! Override the value at a nested provider: }}
     *   <theme.Provide @value={{this.theme}}>
     *     <theme.Provide @value={{this.lightTheme}}>
     *       {{#let theme.value as |t|}}
     *         {{t.color}} {{! the light theme's color }}
     *       {{/let}}
     *     </theme.Provide>
     *   </theme.Provide>
     *
     *   {{theme.value}} {{! throws -- no provider in the hierarchy }}
     * </template>
     * ```
     *
     * Reactivity: the `@value` binding is reactive. When the argument passed to
     * `<Provide>` updates, consumers re-render automatically. If `@value` is a
     * stable object, mutating its `@tracked` fields likewise re-renders
     * consumers.
     *
     * `value` throws if it is read outside of rendering, or if no matching
     * `<Provide>` exists higher in the render tree. This is intentional
     * harm-reduction: a missing provider is almost always a bug, not a
     * legitimate "fall back to undefined" state. If you want a default, provide
     * one at the application root.
     *
     * The returned object also has a `consume()` method. With no argument it
     * behaves exactly like reading `value`. Passed a component instance, it
     * resolves the context from that component's position in the render tree
     * instead -- the way to read a context from event handlers and other code
     * that runs outside of rendering:
     *
     * ```gjs
     * import Component from '@glimmer/component';
     * import { createContext } from '@ember/helper';
     * import { on } from '@ember/modifier';
     *
     * const theme = createContext<Theme>();
     *
     * class ThemedButton extends Component {
     *   onClick = () => {
     *     // Outside of rendering, `theme.value` would throw -- but passing the
     *     // component instance resolves the nearest <theme.Provide> above it.
     *     console.log(theme.consume(this).color);
     *   };
     *
     *   <template>
     *     <button {{on 'click' this.onClick}}>{{yield}}</button>
     *   </template>
     * }
     * ```
     *
     * Any rendered component instance works with every context -- the instance
     * identifies a position in the render tree, not any one context's value.
     * Resolution happens at `consume` time, so the value read is the provider's
     * current `@value`, not a snapshot from render time.
     *
     * @method createContext
     * @static
     * @for @ember/helper
     * @returns {Object} An object with `Provide` (a component that takes a
     *   `@value`), `value` (a getter that reads the nearest provided value), and
     *   `consume` (reads ambiently like `value`, or from a component instance's
     *   position).
     * @public
     */
    export function createContext<T>(): Context<T>;
}