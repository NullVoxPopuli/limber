declare module '@glimmer/runtime/lib/helpers/array' {
    /**
       Use the `{{array}}` helper to create an array to pass as an option to your
       components.

       ```handlebars
       <MyComponent @people={{array
         'Tom Dale'
         'Yehuda Katz'
         this.myOtherPerson}}
       />
       ```
        or
       ```handlebars
       {{yield people=(array
         'Tom Dale'
         'Yehuda Katz'
         this.myOtherPerson)
       }}
       ```

       Would result in an object such as:

       ```js
       ['Tom Dale', 'Yehuda Katz', this.get('myOtherPerson')]
       ```

       Where the 3rd item in the array is bound to updates of the `myOtherPerson` property.

       @method array
       @param {Array} options
       @return {Array} Array
       @public
     */
    export const array: object;
}