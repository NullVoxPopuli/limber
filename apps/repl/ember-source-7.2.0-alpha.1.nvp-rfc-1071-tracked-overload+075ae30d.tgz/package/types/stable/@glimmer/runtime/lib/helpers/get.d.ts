declare module '@glimmer/runtime/lib/helpers/get' {
    /**
      Dynamically look up a property on an object. The second argument to `{{get}}`
      should have a string value, although it can be bound.

      For example, these two usages are equivalent:

      ```app/components/developer-detail.gjs
      import Component from '@glimmer/component';
      import { tracked } from '@glimmer/tracking';
      import { get } from '@ember/object';

      export default class extends Component {
        @tracked developer = {
          name: "Sandi Metz",
          language: "Ruby"
        }
        
        <template>
          {{this.developer.name}}
          {{get this.developer "name"}}
        </template>
      }
      ```

      If there were several facts about a person, the `{{get}}` helper can dynamically
      pick one:

      ```app/templates/application.gjs
      <template>
        <DeveloperDetail @factName="language" />
      </template>
      ```

      ```handlebars
      {{get this.developer @factName}}
      ```

      For a more complex example, this template would allow the user to switch
      between showing the user's height and weight with a click:

      ```app/components/developer-detail.gjs
      import Component from '@glimmer/component';
      import { tracked } from '@glimmer/tracking';
      import { get } from '@ember/object';
        
      export default class extends Component {
        @tracked developer = {
          name: "Sandi Metz",
          language: "Ruby"
        }

        @tracked currentFact = 'name'

        showFact = (fact) => {
          this.currentFact = fact;
        }
        
        <template>
          {{get this.developer this.currentFact}}

          <button {{on 'click' (fn this.showFact "name")}}>Show name</button>
          <button {{on 'click' (fn this.showFact "language")}}>Show language</button>
        </template>
      }
      ```

      @public
      @method get
     */
    export const get: object;
}