declare module '@ember/-internals/glimmer/lib/environment' {
    import type { InternalOwner } from "@ember/-internals/owner";
    import type { EnvironmentDelegate } from "@glimmer/runtime/lib/environment";
    export function _setNotifyRevalidate(fn: () => boolean): void;
    export function _resetInvalidationNotified(): void;
    export function _hasScheduledDestroys(): boolean;
    export function _beginRenderTransaction(): void;
    export function _endRenderTransaction(): void;
    /**
     * Runs pending destructors, then finalizers -- the classic
     * actions-before-destroy queue ordering. Destruction can schedule
     * further destruction, so drain until quiet.
     *
     * Draining is skipped while a drain is already running (the outer
     * loop picks up whatever was scheduled) or while roots are mid-render
     * (running destructors would mutate DOM under the updating VM); in
     * both cases the pending work is picked up by the caller that holds
     * the guard, or by the armed fallback microtask.
     */
    export function _drainScheduledDestroys(): void;
    export class EmberEnvironmentDelegate implements EnvironmentDelegate {
        owner: InternalOwner;
        isInteractive: boolean;
        enableDebugTooling: boolean;
        constructor(owner: InternalOwner, isInteractive: boolean);
        onTransactionCommit(): void;
    }
}