declare module '@ember/-internals/glimmer/lib/base-renderer' {
    import type { Cursor, DebugRenderTree, Environment, RenderResult as GlimmerRenderResult, EvaluationContext, TreeBuilder, ClassicResolver } from "@glimmer/interfaces";
    import type { SimpleDocument, SimpleElement } from "@simple-dom/interface";
    /**
     * The parts of this module, in the order that they appear:
     *
     *   renderComponent()
     *         │
     *         │ finds or creates, one per owner
     *         ▼
     *   BaseRenderer ───► RendererState ───► RendererRoot[] ───► GlimmerRenderResult
     *
     *   the public        the roots and      one per             the rendered
     *   surface           the render loop    rendered tree       DOM
     *
     * Each arrow is also a destroyable parent → child link.
     * The destruction of a part destroys everything to its right.
     *
     * The run loop hooks keep every renderer in the `renderers` list current.
     * They come after `BaseRenderer`.
     */
    export type IBuilder = (env: Environment, cursor: Cursor) => TreeBuilder;
    type IntoTarget = Cursor | Element | SimpleElement;
    /**
     * Wraps a render function so that it runs until its first error.
     * After an error, each call only warns.
     *
     * A failed render leaves the tree in an unknown state.
     * A second render on that tree throws again and hides the first error,
     * and it can repeat without end.
     *
     * Production builds return `fn` as it is.
     */
    export function errorLoopTransaction(fn: () => void): () => void;
    /**
     * ----------------------------------------------------------------------------
     * Roots
     * ----------------------------------------------------------------------------
     */
    /**
     * What `RendererState` needs from a root.
     *
     * - `ComponentRootState` is the only root that this module creates.
     * - `ClassicRootState` in `./renderer` covers outlets and classic components.
     */
    export interface RendererRoot {
        readonly type: string;
        readonly result: GlimmerRenderResult | undefined;
        readonly destroyed: boolean;
        render(): void;
        destroy(): void;
        isFor(possibleRoot: unknown): boolean;
    }
    export class ComponentRootState implements RendererRoot {
        #private;
        readonly type = "component";
        constructor(state: RendererState, definition: object, options: {
            into: Cursor;
            args?: Record<string, unknown>;
        });
        isFor(_possibleRoot: unknown): boolean;
        render(): void;
        destroy(): void;
        get destroyed(): boolean;
        get result(): GlimmerRenderResult | undefined;
    }
    /**
     * ----------------------------------------------------------------------------
     * RendererState
     * ----------------------------------------------------------------------------
     */
    /**
     * The roots of one renderer, and the loop that renders them.
     */
    export class RendererState {
        #private;
        readonly owner: object;
        readonly context: EvaluationContext;
        readonly builder: IBuilder;
        constructor(renderer: BaseRenderer, data: {
            owner: object;
            context: EvaluationContext;
            builder: IBuilder;
        });
        get debug(): {
            roots: RendererRoot[];
            inRenderTransaction: boolean;
            isInteractive: boolean;
        };
        get roots(): RendererRoot[];
        get env(): Environment;
        get isInteractive(): boolean;
        /**
         * Adds a root, and renders it.
         *
         * If a render is in progress, this returns before the root renders.
         * `root.result` is then `undefined` until the next pass of `renderRoots`.
         */
        renderRoot(root: RendererRoot): RendererRoot;
        /**
         * Renders every root, and repeats while a render adds more roots.
         *
         * A component can call `renderComponent` while it renders.
         * The new root waits for the next pass:
         *
         *   pass 1   roots = [a, b]      render a, render b      b adds c
         *   pass 2   roots = [a, b, c]   rerender a, b           render c
         *   stop     pass 2 added no root
         *
         * A rerender of a root with no changes does no DOM work.
         */
        renderRoots(): void;
        scheduleRevalidate(): void;
        /**
         * True when there is nothing to render:
         * no roots, or no tracked value changed after the last render.
         *
         * `CURRENT_TAG` stands for every tag,
         * so one changed value anywhere in the app makes every renderer invalid.
         * Each root then finds out for itself if the change applies to it.
         */
        isValid(): boolean;
        revalidate(): void;
        clearAllRoots(): void;
    }
    /**
     * ----------------------------------------------------------------------------
     * BaseRenderer
     * ----------------------------------------------------------------------------
     */
    export class BaseRenderer {
        /**
         * Creates a renderer that has no router.
         *
         * Its resolver does not know `{{outlet}}` and `{{mount}}`.
         * The `Renderer` in `./renderer` adds those.
         */
        static strict(owner: object, document: SimpleDocument | Document, options: {
            isInteractive: boolean;
            hasDOM?: boolean;
        }): BaseRenderer;
        readonly state: RendererState;
        constructor(owner: object, envOptions: {
            isInteractive: boolean;
            hasDOM: boolean;
        }, document: SimpleDocument, resolver: ClassicResolver, builder: IBuilder);
        get debugRenderTree(): DebugRenderTree;
        isValid(): boolean;
        destroy(): void;
        render(component: object, options: {
            into: IntoTarget;
            args?: Record<string, unknown>;
        }): RendererRoot;
        rerender(): void;
    }
    /**
     * ----------------------------------------------------------------------------
     * Run loop hooks
     * ----------------------------------------------------------------------------
     *
     * Backburner emits `begin` and `end` for each run loop.
     * These two events keep every registered renderer current:
     *
     *   begin ───► loopBegin   each renderer schedules `revalidate`
     *     │                    in the `render` queue
     *     ▼
     *   queues flush           `revalidate` renders the roots,
     *     │                    if a tracked value changed
     *     ▼
     *   end ─────► loopEnd     is every renderer valid?
     *
     *                            yes → resolve `renderSettled()`
     *                            no  → start one more run loop, back to `begin`
     *
     * The answer is "no" when code that ran after the `render` queue
     * changed a tracked value.
     */
    export function _resetRenderers(): void;
    /**
     * Returns a promise that resolves when rendering settles.
     *
     * Rendering is settled when every renderer is valid at the end of a run loop.
     * All callers that wait at the same time get the same promise.
     */
    export function renderSettled(): Promise<void>;
    /**
     * ----------------------------------------------------------------------------
     * renderComponent
     * ----------------------------------------------------------------------------
     */
    /**
     * The returned object from `renderComponent`
     * @public
     * @module @ember/renderer
     */
    export interface RenderResult {
        /**
         * Destroys the render tree and removes all rendered content from the element rendered into
         */
        destroy(): void;
    }
    interface RenderComponentEnv {
        /**
         * When false, modifiers will not run.
         */
        isInteractive?: boolean;
        /**
         * All other options are forwarded to the underlying renderer.
         * (its API is currently private and out of scope for this RFC,
         *  so passing additional things here is also considered private API)
         */
        [rendererOption: string]: unknown;
    }
    /**
     * The application seeds its `renderer:-dom` service which allows for
     * router-aware resolver to resolve {{mount}}
     */
    export function setRenderer(owner: object, renderer: BaseRenderer): void;
    /**
     * Render a component into a DOM element.
     *
     * @method renderComponent
     * @static
     * @for @ember/renderer
     * @param {Object} component The component to render.
     * @param {Object} options
     * @param {Element} options.into Where to render the component in to.
     * @param {Object} [options.owner] Optionally specify the owner to use. This will be used for injections, and overall cleanup.
     * @param {Object} [options.env] Optional renderer configuration
     * @param {Object} [options.args] Optionally pass args in to the component. These may be reactive as long as it is an object or object-like
     * @public
     */
    export function renderComponent(
     /**
      * The component definition to render.
      *
      * Any component that has had its manager registered is valid.
      * For the component-types that ship with ember, manager registration
      * does not need to be worried about.
      */
     component: object,
     { owner, env, into, args, }: {
         /**
          * The element to render the component in to.
          */
         into: IntoTarget;
         /**
          * Optional owner. Defaults to `{}`, can be any object, but will need to implement the [Owner](https://api.emberjs.com/ember/release/classes/Owner) API for components within this render tree to access services.
          */
         owner?: object;
         /**
          * Optionally configure the rendering environment
          */
         env?: RenderComponentEnv;
         /**
          * These args get passed to the rendered component
          *
          * If your args are reactive, re-rendering will happen automatically.
          *
          */
         args?: Record<string, unknown>;
     }
    ): RenderResult;
    export {};
}