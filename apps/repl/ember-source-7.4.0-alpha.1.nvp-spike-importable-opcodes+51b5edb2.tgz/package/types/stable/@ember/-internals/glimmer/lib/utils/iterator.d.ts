declare module '@ember/-internals/glimmer/lib/utils/iterator' {
    import type { Nullable } from "@ember/-internals/utility-types";
    import type { IteratorDelegate } from "@glimmer/reference/lib/iterable";
    export default function toIterator(iterable: unknown): Nullable<IteratorDelegate>;
    export abstract class BoundedIterator implements IteratorDelegate {
        private length;
        private position;
        constructor(length: number);
        isEmpty(): false;
        abstract valueFor(position: number): unknown;
        memoFor(position: number): unknown;
        next(): {
            value: unknown;
            memo: unknown;
        } | null;
    }
    export class ArrayIterator extends BoundedIterator {
        private array;
        static from(iterable: unknown[]): ArrayIterator | null;
        static fromForEachable(object: ForEachable): ArrayIterator | null;
        constructor(array: unknown[]);
        valueFor(position: number): unknown;
    }
    interface NativeIteratorConstructor<T = unknown> {
        new (iterable: Iterator<T>, result: IteratorResult<T>): NativeIterator<T>;
    }
    export abstract class NativeIterator<T = unknown> implements IteratorDelegate {
        private iterable;
        private result;
        static from<T>(this: NativeIteratorConstructor<T>, iterable: Iterable<T>): NativeIterator<T> | null;
        private position;
        constructor(iterable: Iterator<T>, result: IteratorResult<T>);
        isEmpty(): false;
        abstract valueFor(result: IteratorResult<T>, position: number): unknown;
        abstract memoFor(result: IteratorResult<T>, position: number): unknown;
        next(): {
            value: unknown;
            memo: unknown;
        } | null;
    }
    export interface ForEachable {
        forEach(callback: (item: unknown, key: unknown) => void): void;
    }
    export function hasForEach(value: unknown): value is ForEachable;
    export function isNativeIterable(value: unknown): value is Iterable<unknown>;
    export {};
}