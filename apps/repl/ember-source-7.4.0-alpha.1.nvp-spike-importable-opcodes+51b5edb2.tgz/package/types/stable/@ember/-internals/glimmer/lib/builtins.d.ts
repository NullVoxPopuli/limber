declare module '@ember/-internals/glimmer/lib/builtins' {
    /**
     * Fills the resolver's built-in tables. Call it from any code path that
     * resolves helpers or modifiers by name.
     */
    export function ensureBuiltins(): void;
}