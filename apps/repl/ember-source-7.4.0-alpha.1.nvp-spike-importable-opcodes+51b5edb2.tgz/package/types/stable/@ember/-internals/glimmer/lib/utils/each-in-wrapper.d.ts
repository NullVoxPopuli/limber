declare module '@ember/-internals/glimmer/lib/utils/each-in-wrapper' {
    /**
     * Marks a value produced by the `-each-in` keyword so the iterator yields
     * keys and values. Kept apart from the helper so the default iterator does
     * not pull in the helper's dependencies.
     */
    export class EachInWrapper {
        inner: unknown;
        constructor(inner: unknown);
    }
}