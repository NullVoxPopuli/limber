declare module '@ember/-internals/glimmer/lib/utils/each-in-iterator' {
    import type { Nullable } from "@ember/-internals/utility-types";
    import type { IteratorDelegate } from "@glimmer/reference/lib/iterable";
    /**
     * Iteration over keys and values, used by `{{#each-in}}`. The `-each-in`
     * helper registers this as an iterator extension when it loads, so a
     * template without `each-in` does not carry it.
     */
    export function toEachInIterator(iterable: unknown): Nullable<IteratorDelegate>;
}