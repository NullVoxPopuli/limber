declare module '@ember/-internals/glimmer/lib/hooks' {
    import type { IteratorDelegate } from "@glimmer/reference/lib/iterable";
    import type { Tag } from "@glimmer/interfaces";
    /**
     * The hooks the rendering environment needs from the rest of Ember.
     *
     * The defaults here cover plain objects, native arrays, and native
     * iterables, and they schedule work on the microtask queue. The modules
     * that own richer behavior register their versions when an app imports
     * them: `@ember/-internals/metal` for `get` and `set`, `@ember/array` for
     * Ember arrays, the proxy mixin for proxies, and `@ember/runloop` for
     * backburner. An app that imports none of them ships none of them.
     */
    export interface EnvironmentHooks {
        getProp(obj: object, key: string): unknown;
        setProp(obj: object, key: string, value: unknown): unknown;
        getPath(obj: object, path: string): unknown;
        setPath(obj: object, path: string, value: unknown): unknown;
        tagForProperty(obj: object, key: string): Tag;
        isEmberArray(value: unknown): boolean;
        objectAt(array: object, index: number): unknown;
        isProxy(value: unknown): boolean;
    }
    export interface RunloopHooks {
        ensureInstance(): void;
        hasCurrentRunLoop(): boolean;
        join(fn: () => void): void;
        scheduleActions(fn: () => void): void;
        scheduleDestroy(fn: () => void): void;
        scheduleOnceRender(target: object, method: (this: any, arg: any) => void, arg: unknown): void;
        on(event: "begin" | "end", fn: () => void): void;
    }
    export const hooks: EnvironmentHooks;
    export function registerEnvironmentHooks(overrides: Partial<EnvironmentHooks>): void;
    export type IteratorExtension = (value: unknown) => IteratorDelegate | null | undefined;
    /**
     * Extra ways to iterate a value, tried before the defaults. A helper that
     * produces its own iterable wrapper registers one when it loads.
     */
    export const iteratorExtensions: IteratorExtension[];
    export function extendToIterator(extension: IteratorExtension): void;
    export let runloop: RunloopHooks;
    /**
     * Replaces the microtask loop. Listeners already attached to the default
     * loop move to the new one, so import order between `@ember/runloop` and
     * the renderer does not matter.
     */
    export function registerRunloop(impl: RunloopHooks): void;
    export function toBool(predicate: unknown): boolean;
    export type { IteratorDelegate };
}