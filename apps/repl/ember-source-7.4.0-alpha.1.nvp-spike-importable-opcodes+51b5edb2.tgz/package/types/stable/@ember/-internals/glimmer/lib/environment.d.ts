declare module '@ember/-internals/glimmer/lib/environment' {
    import type { InternalOwner } from "@ember/-internals/owner";
    import type { DebugRenderTree } from "@glimmer/interfaces";
    import type { EnvironmentDelegate } from "@glimmer/runtime/lib/environment";
    global {
        interface ImportMetaEnv {
            VITE_NO_DEBUG_RENDER_TREE?: string;
        }
    }
    export class EmberEnvironmentDelegate implements EnvironmentDelegate {
        owner: InternalOwner;
        isInteractive: boolean;
        enableDebugTooling: boolean;
        /**
         * The Ember Inspector reads this tree. An app that never uses the
         * inspector in a given build can leave it out by setting
         * `VITE_NO_DEBUG_RENDER_TREE=true` for its Vite build, which drops the
         * implementation from the bundle.
         */
        debugRenderTree: DebugRenderTree<object> | undefined;
        constructor(owner: InternalOwner, isInteractive: boolean);
        onTransactionCommit(): void;
    }
}