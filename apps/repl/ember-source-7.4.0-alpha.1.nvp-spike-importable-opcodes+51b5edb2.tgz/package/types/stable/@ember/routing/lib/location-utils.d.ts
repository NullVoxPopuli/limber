declare module '@ember/routing/lib/location-utils' {
    /**
      @private

      Escapes any regular-expression metacharacters in `str` so it can be safely
      interpolated into a `RegExp` and matched as a literal.

      TODO: delete this in favor of `RegExp.escape` once our minimum supported
      browsers all include it (https://caniuse.com/mdn-javascript_builtins_regexp_escape).
    */
    export function escapeRegExp(str: string): string;
    /**
      @private

      Returns the current `location.pathname`, ensuring it has a leading slash.
    */
    export function getPath(location: Location): string;
    /**
      @private

      Returns the current `location.search`.
    */
    export function getQuery(location: Location): string;
    /**
      @private

      Returns the hash or empty string
    */
    export function getHash(location: Location): string;
    export function getFullPath(location: Location): string;
}