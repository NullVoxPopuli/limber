declare module '@ember/array/lib/iterator-extension' {
    export {};
}