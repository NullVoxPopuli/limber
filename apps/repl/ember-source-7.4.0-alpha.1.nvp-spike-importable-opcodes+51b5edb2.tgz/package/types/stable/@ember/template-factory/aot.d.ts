declare module '@ember/template-factory/aot' {
    export { default as createTemplateFactory } from "@glimmer/opcode-compiler/lib/aot/template";
}