declare module '@ember/template-factory/modular' {
    export { default as createTemplateFactory } from "@glimmer/opcode-compiler/lib/template-jit";
}