declare module 'ember-template-compiler/lib/system/precompile-module' {
    import { type PrecompiledModule } from "@glimmer/compiler";
    import type { EmberPrecompileOptions } from "ember-template-compiler/lib/types";
    /**
      Compiles a template into a JavaScript expression plus the imports it
      needs. A strict template compiles all the way to VM words, so no compiler
      ships to the browser for it. A loose template keeps its wire format
      opcodes as imported objects and resolves names at runtime.

      @private
      @method precompileModule
    */
    export default function precompileModule(templateString: string, options?: Partial<EmberPrecompileOptions>): PrecompiledModule;
}