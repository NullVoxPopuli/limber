declare module '@glimmer/program/lib/util/default-template' {
    import type { AotTemplate } from "@glimmer/opcode-compiler/lib/aot/template";
    import { DEFAULT_TEMPLATE_WRAPPED } from "@glimmer/opcode-compiler/lib/opcode-builder/stdlib-data";
    /**
     * Default component template, which is a plain yield. Compiled ahead of
     * time by `bin/build-aot-stdlib.mjs`, in both plain and wrapped forms.
     */
    export const DEFAULT_TEMPLATE: AotTemplate;
    export { DEFAULT_TEMPLATE_WRAPPED };
}