declare module '@glimmer/program/lib/definitions' {
    import type { ComponentDefinition, HelperDefinitionState, ModifierDefinitionState, ProgramConstants, ResolvedComponentDefinition } from "@glimmer/interfaces";
    export function helperHandle(
      constants: ProgramConstants,
      definitionState: HelperDefinitionState,
      _resolvedName: string | null,
      isOptional: true
    ): number | null;
    export function helperHandle(
      constants: ProgramConstants,
      definitionState: HelperDefinitionState,
      _resolvedName?: string | null
    ): number;
    export function modifierHandle(
      constants: ProgramConstants,
      definitionState: ModifierDefinitionState,
      resolvedName: string | null,
      isOptional: true
    ): number | null;
    export function modifierHandle(
      constants: ProgramConstants,
      definitionState: ModifierDefinitionState,
      resolvedName?: string | null
    ): number;
    export function resolvedComponentDefinition(
      constants: ProgramConstants,
      resolvedDefinition: ResolvedComponentDefinition,
      resolvedName: string
    ): ComponentDefinition;
}