declare module '@glimmer/program/lib/constants' {
    import type { ComponentDefinition, ComponentDefinitionState, ConstantPool, ProgramConstants, Template } from "@glimmer/interfaces";
    export class ConstantsImpl implements ProgramConstants {
        protected reifiedArrs: {
            [key: number]: unknown[];
        };
        defaultTemplate: Template;
        componentDefinitionCount: number;
        helperDefinitionCount: number;
        modifierDefinitionCount: number;
        private values;
        private indexMap;
        private componentDefinitionCache;
        value(value: unknown): number;
        array(values: unknown[]): number;
        toPool(): ConstantPool;
        hasHandle(handle: number): boolean;
        component(definitionState: ComponentDefinitionState, owner: object): ComponentDefinition;
        getValue<T>(index: number): T;
        getArray<T>(index: number): T[];
    }
}