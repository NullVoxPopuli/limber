declare module '@glimmer/compiler' {
    export { buildStatement, buildStatements, c, NEWLINE, ProgramSymbols, s, unicode, } from "@glimmer/compiler/lib/builder/builder";
    export { type BuilderStatement } from "@glimmer/compiler/lib/builder/builder-interface";
    export { defaultId, precompile, precompileModule, type PrecompiledModule, precompileJSON, type PrecompileOptions, } from "@glimmer/compiler/lib/compiler";
    export { default as WireFormatDebugger } from "@glimmer/compiler/lib/wire-format-debug";
    export type { ModuleExport, OpImport } from "@glimmer/compiler/lib/wire-format-module";
}