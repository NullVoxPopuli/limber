declare module '@glimmer/compiler/lib/compiler' {
    import type { Nullable, SerializedTemplateBlock, TemplateJavascript } from "@glimmer/interfaces";
    import type { PrecompileOptions, PrecompileOptionsWithLexicalScope, TemplateIdFn } from "@glimmer/syntax/lib/parser/tokenizer-event-handlers";
    import { type ModuleExport, type OpImport } from "@glimmer/compiler/lib/wire-format-module";
    export const defaultId: TemplateIdFn;
    export function precompileJSON(
     string: Nullable<string>,
     options?: PrecompileOptions | PrecompileOptionsWithLexicalScope
    ): [block: SerializedTemplateBlock, usedLocals: string[]];
    export function precompile(
     source: string,
     options?: PrecompileOptions | PrecompileOptionsWithLexicalScope
    ): TemplateJavascript;
    export interface PrecompiledModule {
        /** Identifiers in `expression` that must be bound to imports. */
        imports: OpImport[];
        /** The template factory the build tool must wrap `expression` in. */
        factory: ModuleExport;
        /** A JavaScript expression that evaluates to a `SerializedTemplateWithOps`. */
        expression: string;
    }
    /**
     * Like `precompile`, but the block is JavaScript that references its wire
     * format opcodes by identifier instead of a JSON string. The caller adds an
     * import for each entry of `imports` and renames the identifier as needed.
     */
    export function precompileModule(
     source: string,
     options?: PrecompileOptions | PrecompileOptionsWithLexicalScope
    ): PrecompiledModule;
    export type { PrecompileOptions };
}