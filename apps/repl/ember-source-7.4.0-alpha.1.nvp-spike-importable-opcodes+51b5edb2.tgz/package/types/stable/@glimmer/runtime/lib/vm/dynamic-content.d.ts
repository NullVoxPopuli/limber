declare module '@glimmer/runtime/lib/vm/dynamic-content' {
    import type { SimpleDocumentFragment, SimpleNode, TreeBuilder } from "@glimmer/interfaces";
    /**
     * Appending dynamic content: `{{{html}}}`, safe strings, fragments, and
     * nodes. Text has its own path on the tree builder. These were methods
     * on the builder, which kept them in every bundle.
     */
    export function appendDynamicHTML(tree: TreeBuilder, value: string): void;
    export function appendDynamicFragment(tree: TreeBuilder, value: SimpleDocumentFragment): void;
    export function appendDynamicNode(tree: TreeBuilder, value: SimpleNode): void;
}