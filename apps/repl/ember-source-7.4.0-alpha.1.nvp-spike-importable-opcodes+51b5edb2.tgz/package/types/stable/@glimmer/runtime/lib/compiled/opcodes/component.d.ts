declare module '@glimmer/runtime/lib/compiled/opcodes/component' {
    import type { DynamicAttributeApplier, Bounds, CapabilityMask, CapturedArguments, ComponentDefinition, ComponentDefinitionState, ComponentInstanceState, ComponentInstanceWithCreate, Dict, DynamicScope, ElementOperations, InternalComponentManager, ModifierInstance, Nullable, ProgramSymbolTable, ScopeSlot, UpdatingOpcode, WithUpdateHook } from "@glimmer/interfaces";
    import type { Reference } from "@glimmer/reference/lib/reference";
    import type { UpdatingVM } from "@glimmer/runtime/lib/vm";
    import type { VM } from "@glimmer/runtime/lib/vm/append";
    /**
     * The VM creates a new ComponentInstance data structure for every component
     * invocation it encounters.
     *
     * Similar to how a ComponentDefinition contains state about all components of a
     * particular type, a ComponentInstance contains state specific to a particular
     * instance of a component type. It also contains a pointer back to its
     * component type's ComponentDefinition.
     */
    export interface InitialComponentInstance {
        definition: ComponentDefinition;
        manager: Nullable<InternalComponentManager>;
        capabilities: Nullable<CapabilityMask>;
        state: null;
        handle: Nullable<number>;
        table: Nullable<ProgramSymbolTable>;
        lookup: Nullable<Dict<ScopeSlot>>;
    }
    export interface PopulatedComponentInstance {
        definition: ComponentDefinition;
        manager: InternalComponentManager;
        capabilities: CapabilityMask;
        state: null;
        handle: number;
        table: Nullable<ProgramSymbolTable>;
        lookup: Nullable<Dict<ScopeSlot>>;
    }
    export interface PartialComponentDefinition {
        state: Nullable<ComponentDefinitionState>;
        manager: InternalComponentManager;
    }
    export const PUSH_COMPONENT_DEFINITION_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<78>;
    export const RESOLVE_DYNAMIC_COMPONENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<80>;
    export const RESOLVE_CURRIED_COMPONENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<81>;
    export const PUSH_DYNAMIC_COMPONENT_INSTANCE_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<79>;
    export const PUSH_ARGS_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<82>;
    export const PUSH_EMPTY_ARGS_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<83>;
    export const CAPTURE_ARGS_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<86>;
    export const PREPARE_ARGS_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<85>;
    export const CREATE_COMPONENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<87>;
    export const REGISTER_COMPONENT_DESTRUCTOR_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<88>;
    export const BEGIN_COMPONENT_TRANSACTION_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<97>;
    export const PUT_COMPONENT_OPERATIONS_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<89>;
    export const COMPONENT_ATTR_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<53>;
    export const STATIC_COMPONENT_ATTR_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<105>;
    export class ComponentElementOperations implements ElementOperations {
        private attributes;
        private classes;
        private modifiers;
        private applyDynamic;
        setAttribute(name: string, value: Reference, trusting: boolean, namespace: Nullable<string>, apply?: DynamicAttributeApplier): void;
        setStaticAttribute(name: string, value: string, namespace: Nullable<string>): void;
        addModifier(vm: VM, modifier: ModifierInstance, capturedArgs: CapturedArguments): void;
        flush(vm: VM): ModifierInstance[];
        private setDeferredAttr;
    }
    export const DID_CREATE_ELEMENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<99>;
    export const GET_COMPONENT_SELF_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<90>;
    export const GET_COMPONENT_TAG_NAME_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<91>;
    export const GET_COMPONENT_LAYOUT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<92>;
    export const MAIN_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<75>;
    export const POPULATE_LAYOUT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<95>;
    export const VIRTUAL_ROOT_SCOPE_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<38>;
    export const SET_NAMED_VARIABLES_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<17>;
    export const SET_BLOCKS_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<18>;
    export const INVOKE_COMPONENT_LAYOUT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<96>;
    export const DID_RENDER_LAYOUT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<100>;
    export const COMMIT_COMPONENT_TRANSACTION_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<98>;
    export class UpdateComponentOpcode implements UpdatingOpcode {
        private component;
        private manager;
        private dynamicScope;
        constructor(component: ComponentInstanceState, manager: WithUpdateHook, dynamicScope: Nullable<DynamicScope>);
        evaluate(_vm: UpdatingVM): void;
    }
    export class DidUpdateLayoutOpcode implements UpdatingOpcode {
        private component;
        private bounds;
        constructor(component: ComponentInstanceWithCreate, bounds: Bounds);
        evaluate(vm: UpdatingVM): void;
    }
}