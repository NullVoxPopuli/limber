declare module '@glimmer/runtime/lib/compiled/opcodes/content' {
    export const CONTENT_TYPE_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<76>;
    export const DYNAMIC_CONTENT_TYPE_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<106>;
    export const APPEND_HTML_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<43>;
    export const APPEND_SAFE_HTML_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<44>;
    export const APPEND_TEXT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<47>;
    export const APPEND_DOCUMENT_FRAGMENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<45>;
    export const APPEND_NODE_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<46>;
}