declare module '@glimmer/runtime/lib/vm/lists' {
    import type { AppendingBlock, Bounds, Reference, SimpleElement, SimpleNode, TreeBuilder } from "@glimmer/interfaces";
    import type { OpaqueIterationItem, OpaqueIterator } from "@glimmer/reference/lib/iterable";
    import type { VM } from "@glimmer/runtime/lib/vm/append";
    import { type ListItemOpcode } from "@glimmer/runtime/lib/vm/update";
    /**
     * List iteration for `{{#each}}`. These used to be VM methods, which kept
     * `ListBlockOpcode` in every bundle. The list handlers import them, so a
     * template without `{{#each}}` drops them.
     */
    export function enterList(vm: VM, iterableRef: Reference<OpaqueIterator>, offset: number): void;
    export function registerItem(vm: VM, opcode: ListItemOpcode): void;
    export function enterItem(vm: VM, item: OpaqueIterationItem): ListItemOpcode;
    export function exitList(vm: VM): void;
    export class AppendingBlockList implements AppendingBlock {
        private readonly parent;
        boundList: Bounds[];
        constructor(parent: SimpleElement, boundList: Bounds[]);
        parentElement(): SimpleElement;
        firstNode(): SimpleNode;
        lastNode(): SimpleNode;
        openElement(_element: SimpleElement): void;
        closeElement(): void;
        didAppendNode(_node: SimpleNode): void;
        didAppendBounds(_bounds: Bounds): void;
        finalize(_stack: TreeBuilder): void;
    }
}