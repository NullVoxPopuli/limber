declare module '@glimmer/runtime/lib/opcodes' {
    import type { DebugOp, SomeDisassembledOperand } from "@glimmer/debug/lib/debug";
    import type { DebugVmSnapshot, Dict, Nullable, Optional, RuntimeOp, VmMachineOp, VmOp } from "@glimmer/interfaces";
    import { VmSnapshot } from "@glimmer/debug/lib/vm/snapshot";
    import type { LowLevelVM, VM } from "@glimmer/runtime/lib/vm";
    import type { Externs } from "@glimmer/runtime/lib/vm/low-level";
    export interface OpcodeJSON {
        type: number | string;
        guid?: Nullable<number>;
        deopted?: boolean;
        args?: string[];
        details?: Dict<Nullable<string>>;
        children?: OpcodeJSON[];
    }
    export type Operand1 = number;
    export type Operand2 = number;
    export type Operand3 = number;
    export type Syscall = (vm: VM, opcode: RuntimeOp) => void;
    export type MachineOpcode = (vm: LowLevelVM, opcode: RuntimeOp) => void;
    export interface SyscallHandler<Name extends VmOp = VmOp> {
        readonly type: Name;
        readonly evaluate: Syscall;
    }
    /**
     * Wraps a syscall handler with its opcode number. Nothing is registered here.
     * The encoder registers the handler when a template pushes it, so an opcode
     * that no template uses is dropped by the bundler.
     */
    export function syscall<Name extends VmOp>(type: Name, evaluate: Syscall): SyscallHandler<Name>;
    export type Evaluate = {
        syscall: true;
        evaluate: Syscall;
    } | {
        syscall: false;
        evaluate: MachineOpcode;
    };
    export type DebugState = {
        opcode: {
            type: VmMachineOp | VmOp;
            isMachine: 0 | 1;
            size: number;
        };
        closeGroup?: undefined | (() => void);
        params?: Optional<Dict<SomeDisassembledOperand>>;
        op?: Optional<DebugOp>;
        debug: DebugVmSnapshot;
        snapshot: VmSnapshot;
    };
    export class AppendOpcodes {
        private evaluateOpcode;
        debugBefore?: (vm: DebugVmSnapshot, opcode: RuntimeOp) => DebugState;
        debugAfter?: (debug: DebugVmSnapshot, pre: DebugState) => void;
        constructor();
        /**
         * Registers a handler the first time an encoder pushes its opcode. Later
         * calls for the same opcode are no-ops, so import order does not matter.
         */
        register(handler: SyscallHandler): void;
        evaluate(vm: VM, opcode: RuntimeOp, type: number): void;
    }
    export function externs(vm: VM): Externs | undefined;
    export const APPEND_OPCODES: AppendOpcodes;
}