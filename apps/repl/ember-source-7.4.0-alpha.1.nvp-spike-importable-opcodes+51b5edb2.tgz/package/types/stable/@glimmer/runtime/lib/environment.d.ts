declare module '@glimmer/runtime/lib/environment' {
    import type { ClassicResolver, CommitHook, ComponentInstanceWithCreate, DebugRenderTree, Environment, EnvironmentOptions, GlimmerTreeChanges, GlimmerTreeConstruction, Nullable, RuntimeArtifacts, RuntimeOptions, Transaction, TransactionSymbol } from "@glimmer/interfaces";
    export const TRANSACTION: TransactionSymbol;
    class TransactionImpl implements Transaction {
        createdComponents: ComponentInstanceWithCreate[];
        updatedComponents: ComponentInstanceWithCreate[];
        private hooks;
        private items;
        didCreate(component: ComponentInstanceWithCreate): void;
        didUpdate(component: ComponentInstanceWithCreate): void;
        schedule<T>(hook: CommitHook<T>, item: T): void;
        commit(): void;
    }
    export class EnvironmentImpl implements Environment {
        private delegate;
        [TRANSACTION]: Nullable<TransactionImpl>;
        protected appendOperations: GlimmerTreeConstruction;
        protected updateOperations?: GlimmerTreeChanges | undefined;
        isInteractive: boolean;
        isArgumentCaptureError: ((error: any) => boolean) | undefined;
        debugRenderTree: DebugRenderTree | undefined;
        constructor(options: EnvironmentOptions, delegate: EnvironmentDelegate);
        getAppendOperations(): GlimmerTreeConstruction;
        getDOM(): GlimmerTreeChanges;
        begin(): void;
        private get transaction();
        didCreate(component: ComponentInstanceWithCreate): void;
        didUpdate(component: ComponentInstanceWithCreate): void;
        /**
         * Queues work for the end of the current transaction. The hook runs once
         * per transaction with everything queued under it, so the code behind a
         * kind of work (modifier installs, for example) lives with the opcode
         * that queues it instead of here.
         */
        schedule<T>(hook: CommitHook<T>, item: T): void;
        commit(): void;
    }
    export interface EnvironmentDelegate {
        /**
         * Used to determine the the environment is interactive (e.g. SSR is not
         * interactive). Interactive environments schedule modifiers, among other things.
         */
        isInteractive: boolean;
        /**
         * Used to enable debug tooling
         */
        enableDebugTooling: boolean;
        /**
         * The render tree for debug tooling, if the host wants one. The host
         * constructs it, so a build that never wants one does not carry the
         * implementation.
         */
        debugRenderTree?: DebugRenderTree | undefined;
        /**
         * Callback to be called when an environment transaction commits
         */
        onTransactionCommit: () => void;
    }
    export function runtimeOptions(
     options: EnvironmentOptions,
     delegate: EnvironmentDelegate,
     artifacts: RuntimeArtifacts,
     resolver: Nullable<ClassicResolver>
    ): RuntimeOptions;
    export function inTransaction(env: Environment, block: () => void): void;
    export default EnvironmentImpl;
}