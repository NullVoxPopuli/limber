declare module '@glimmer/runtime/lib/compiled/opcodes/lists' {
    export const ENTER_LIST_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<72>;
    export const EXIT_LIST_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<73>;
    export const ITERATE_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<74>;
}