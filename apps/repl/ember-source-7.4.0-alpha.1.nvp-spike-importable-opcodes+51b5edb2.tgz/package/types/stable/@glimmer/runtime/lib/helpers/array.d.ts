declare module '@glimmer/runtime/lib/helpers/array' {
    export const array: object;
}