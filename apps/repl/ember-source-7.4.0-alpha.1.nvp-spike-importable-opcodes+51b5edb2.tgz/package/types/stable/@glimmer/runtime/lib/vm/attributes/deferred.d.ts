declare module '@glimmer/runtime/lib/vm/attributes/deferred' {
    import type { DynamicAttributeApplier } from "@glimmer/interfaces";
    export const applyDynamicAttribute: DynamicAttributeApplier;
}