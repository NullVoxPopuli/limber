declare module '@glimmer/runtime/lib/debug-render-tree' {
    import type { Bounds, CapturedArguments, CapturedRenderNode, ComponentDefinition, ComponentInstance, DebugRenderTree, Environment, ModifierInstance, Nullable, RenderNode, UpdatingOpcode } from "@glimmer/interfaces";
    import type { Reference } from "@glimmer/reference/lib/reference";
    import type { VM } from "@glimmer/runtime/lib/vm/append";
    import type { UpdatingVM } from "@glimmer/runtime/lib/vm";
    export class Ref<T extends object> {
        readonly id: number;
        private value;
        constructor(value: T);
        get(): Nullable<T>;
        release(): void;
        toString(): string;
    }
    export default class DebugRenderTreeImpl<TBucket extends object> implements DebugRenderTree<TBucket> {
        private stack;
        private refs;
        private roots;
        private nodes;
        begin(): void;
        create(state: TBucket, node: RenderNode): void;
        update(state: TBucket): void;
        didRender(state: TBucket, bounds: Bounds): void;
        willDestroy(state: TBucket): void;
        commit(): void;
        componentDidGetSelf(vm: VM, instance: ComponentInstance, selfRef: Reference, namesHandle: number): void;
        componentDidRenderLayout(vm: VM, instance: ComponentInstance, bounds: Bounds): void;
        modifierDidAdd(vm: VM, modifier: ModifierInstance, capturedArgs: CapturedArguments): void;
        remoteElementDidPush(block: object, elementRef: Reference, insertBeforeRef: Reference, insertBefore: unknown): void;
        capture(): CapturedRenderNode[];
        private reset;
        private enter;
        private exit;
        private nodeFor;
        private appendChild;
        private captureRefs;
        private captureNode;
        private captureBounds;
    }
    export function getDebugName(
        definition: ComponentDefinition,
        manager?: import("@glimmer/interfaces").InternalComponentManager<unknown, object>
    ): string;
    /**
     * The bookkeeping the VM does on behalf of the debug render tree. It lives
     * on the tree object rather than in the opcode handlers so that a build
     * which leaves the tree out also leaves this out.
     */
    export interface RuntimeDebugRenderTree extends DebugRenderTree {
        componentDidGetSelf(vm: VM, instance: ComponentInstance, selfRef: Reference, namesHandle: number): void;
        componentDidRenderLayout(vm: VM, instance: ComponentInstance, bounds: Bounds): void;
        modifierDidAdd(vm: VM, modifier: ModifierInstance, args: CapturedArguments): void;
        remoteElementDidPush(block: object, elementRef: Reference, insertBeforeRef: Reference, insertBefore: unknown): void;
    }
    /**
     * The environment types its tree as the host-facing `DebugRenderTree`. The
     * runtime only ever receives `DebugRenderTreeImpl`, which also carries the
     * VM hooks.
     */
    export function debugTree(env: Environment): RuntimeDebugRenderTree | undefined;
    export class DebugRenderTreeUpdateOpcode implements UpdatingOpcode {
        private bucket;
        constructor(bucket: object);
        evaluate(vm: UpdatingVM): void;
    }
    export class DebugRenderTreeDidRenderOpcode implements UpdatingOpcode {
        private bucket;
        private bounds;
        constructor(bucket: object, bounds: Bounds);
        evaluate(vm: UpdatingVM): void;
    }
}