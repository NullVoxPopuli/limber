declare module '@glimmer/runtime/lib/vm/modifiers' {
    import type { Environment, ModifierInstance } from "@glimmer/interfaces";
    export function scheduleInstallModifier(env: Environment, modifier: ModifierInstance): void;
    export function scheduleUpdateModifier(env: Environment, modifier: ModifierInstance): void;
}