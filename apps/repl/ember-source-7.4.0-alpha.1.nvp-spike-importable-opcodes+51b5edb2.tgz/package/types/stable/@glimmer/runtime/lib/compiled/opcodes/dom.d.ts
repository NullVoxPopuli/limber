declare module '@glimmer/runtime/lib/compiled/opcodes/dom' {
    import type { Environment, ModifierInstance, UpdatingOpcode, UpdatingVM } from "@glimmer/interfaces";
    import type { Reference } from "@glimmer/reference/lib/reference";
    import type { Tag } from "@glimmer/interfaces";
    import type { DynamicAttribute } from "@glimmer/runtime/lib/vm/attributes/dynamic";
    export const TEXT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<41>;
    export const COMMENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<42>;
    export const OPEN_ELEMENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<48>;
    export const OPEN_DYNAMIC_ELEMENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<49>;
    export const PUSH_REMOTE_ELEMENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<50>;
    export const POP_REMOTE_ELEMENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<56>;
    export const FLUSH_ELEMENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<54>;
    export const CLOSE_ELEMENT_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<55>;
    export const MODIFIER_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<57>;
    export const DYNAMIC_MODIFIER_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<108>;
    export class UpdateModifierOpcode implements UpdatingOpcode {
        private tag;
        private modifier;
        private lastUpdated;
        constructor(tag: Tag, modifier: ModifierInstance);
        evaluate(vm: UpdatingVM): void;
    }
    export class UpdateDynamicModifierOpcode implements UpdatingOpcode {
        private tag;
        private instance;
        private instanceRef;
        private lastUpdated;
        constructor(tag: Tag | null, instance: ModifierInstance | undefined, instanceRef: Reference<ModifierInstance | undefined>);
        evaluate(vm: UpdatingVM): void;
    }
    export const STATIC_ATTR_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<51>;
    export const DYNAMIC_ATTR_OP: import("@glimmer/runtime/lib/opcodes").SyscallHandler<52>;
    export class UpdateDynamicAttributeOpcode implements UpdatingOpcode {
        private updateRef;
        constructor(reference: Reference, attribute: DynamicAttribute, env: Environment);
        evaluate(): void;
    }
}