declare module '@glimmer/opcode-compiler/lib/syntax/expressions' {
    export const ConcatOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.Concat>;
    export const CallOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.Helper>;
    export const CurryOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.Curry>;
    export const GetSymbolOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.GetSymbol | import("@glimmer/interfaces").Expressions.GetPathSymbol>;
    export const GetLexicalSymbolOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.GetLexicalSymbol | import("@glimmer/interfaces").Expressions.GetPathTemplateSymbol>;
    export const GetStrictKeywordOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.GetStrictFree>;
    export const GetFreeAsHelperHeadOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.GetFreeAsHelperHead | import("@glimmer/interfaces").Expressions.GetPathFreeAsHelperHead>;
    export const UndefinedOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.Undefined>;
    export const HasBlockOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.HasBlock>;
    export const HasBlockParamsOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.HasBlockParams>;
    export const IfInlineOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.IfInline>;
    export const NotOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.Not>;
    export const GetDynamicVarOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.GetDynamicVar>;
    export const LogOp: import("@glimmer/opcode-compiler/lib/syntax/compilers").SexpOp<import("@glimmer/interfaces").Expressions.Log>;
}