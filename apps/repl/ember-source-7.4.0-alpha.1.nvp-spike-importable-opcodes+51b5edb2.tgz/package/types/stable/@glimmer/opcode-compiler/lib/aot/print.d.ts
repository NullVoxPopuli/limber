declare module '@glimmer/opcode-compiler/lib/aot/print' {
    import type { RecordedConstant, RecordedProgram } from "@glimmer/opcode-compiler/lib/aot/record";
    export const TEMPLATE_MODULE = "@glimmer/opcode-compiler/lib/aot/template";
    export const STDLIB_MODULE = "@glimmer/opcode-compiler/lib/opcode-builder/stdlib-data";
    export function stdlibExportName(routine: string): string;
    /** Returns the local identifier for an import, adding the import on first use. */
    export type Bind = (local: string, module: string, name: string) => string;
    /**
     * Prints a recorded block as the `AotBlock` array literal the loader
     * expects. Opcode handlers and stdlib routines print as identifiers that
     * the caller binds to imports; everything else is JSON.
     */
    export function printBlock(
     symbols: string[],
     constants: RecordedConstant[],
     programs: RecordedProgram[],
     bind: Bind
    ): string;
}