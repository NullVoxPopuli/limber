declare module '@glimmer/opcode-compiler/lib/aot/handlers' {
    export interface HandlerImport {
        module: string;
        name: string;
    }
    /**
     * Maps a syscall opcode number to the export that handles it. Build-time
     * only: this module imports every handler.
     */
    export function handlerImports(): Map<number, HandlerImport>;
    export function handlerFor(type: number): HandlerImport;
}