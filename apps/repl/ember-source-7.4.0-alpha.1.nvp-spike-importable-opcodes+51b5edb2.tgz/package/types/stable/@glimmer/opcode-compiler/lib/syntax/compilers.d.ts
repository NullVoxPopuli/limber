declare module '@glimmer/opcode-compiler/lib/syntax/compilers' {
    import type { BuilderOp, HighLevelOp, SexpOpcode, SexpOpcodeMap } from "@glimmer/interfaces";
    export type PushExpressionOp = (...op: BuilderOp | HighLevelOp) => void;
    const STATEMENT: unique symbol;
    export type HighLevelStatementOp = [{
        [STATEMENT]: undefined;
    }];
    export type PushStatementOp = (...op: BuilderOp | HighLevelOp | HighLevelStatementOp) => void;
    export type CompilerFunction<PushOp extends PushExpressionOp, TSexp> = (op: PushOp, sexp: TSexp) => void;
    /**
     * A wire format opcode that a compiled template imports. The tuple head of a
     * statement or expression is one of these objects. `id` is the numeric
     * SexpOpcode, kept for debug output and for templates that still ship JSON.
     */
    export interface SexpOp<TSexp = unknown> {
        readonly id: SexpOpcode;
        readonly compile: CompilerFunction<PushStatementOp, TSexp>;
        /**
         * A variant compiles a narrower shape of the same numeric opcode. Only the
         * module printer emits it, so the legacy table for JSON blocks skips it.
         */
        readonly variant?: boolean;
    }
    export function defineStatement<T extends SexpOpcode>(
        id: T,
        compile: CompilerFunction<PushStatementOp, SexpOpcodeMap[T]>,
        options?: {
            variant: boolean;
        }
    ): SexpOp<SexpOpcodeMap[T]>;
    export function defineExpression<T extends SexpOpcode>(id: T, compile: CompilerFunction<PushExpressionOp, SexpOpcodeMap[T]>): SexpOp<SexpOpcodeMap[T]>;
    /**
     * Templates that ship a JSON block have numeric heads. `./legacy` fills this
     * table with every op. Templates that import their ops never need it.
     */
    export const LEGACY_OPS: {
        [id: number]: SexpOp | undefined;
    };
    export function headId(sexp: readonly unknown[]): SexpOpcode;
    export function compileSexp(op: PushStatementOp, sexp: readonly unknown[]): void;
    export {};
}