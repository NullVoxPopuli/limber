declare module '@glimmer/opcode-compiler/lib/aot/precompile' {
    import type { PrecompiledModule, PrecompileOptions } from "@glimmer/compiler/lib/compiler";
    import type { ModuleExport } from "@glimmer/compiler/lib/wire-format-module";
    export interface PrecompileAotOptions extends PrecompileOptions {
        lexicalScope?: (variable: string) => boolean;
        /** The template factory the build tool wraps the expression in. */
        factory?: ModuleExport;
    }
    /**
     * Compiles a strict template all the way to VM words. The output has the
     * same shape as `precompileModule`: a serialized template expression plus
     * the identifiers a build tool must bind to imports. The `block` holds
     * words instead of wire format, and the loader reads lexical values from
     * `scope` by position, the way the browser compiler does.
     */
    export function precompileAot(source: string, options: PrecompileAotOptions): PrecompiledModule;
}