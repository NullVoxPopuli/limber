declare module '@glimmer/opcode-compiler/lib/opcode-builder/encoder' {
    import type { BlockMetadata, BuilderOp, BuilderOpcode, CompileTimeConstants, Dict, Encoder, EncoderError, EvaluationContext, HandleResult, HighLevelOp, ProgramHeap, SingleBuilderOperand, STDLib } from "@glimmer/interfaces";
    export class Labels {
        labels: Dict<number>;
        targets: Array<{
            at: number;
            target: string;
        }>;
        label(name: string, index: number): void;
        target(at: number, target: string): void;
        patch(heap: ProgramHeap): void;
    }
    export function encodeOp(
        encoder: Encoder,
        context: EvaluationContext,
        meta: BlockMetadata,
        op: BuilderOp | HighLevelOp
    ): void;
    export class EncoderImpl implements Encoder {
        private heap;
        private meta;
        private stdlib?;
        private labelsStack;
        private encoder;
        private errors;
        private handle;
        private stdlibFixups;
        constructor(heap: ProgramHeap, meta: BlockMetadata, stdlib?: STDLib | undefined);
        error(error: EncoderError): void;
        commit(size: number): HandleResult;
        push(constants: CompileTimeConstants, type: BuilderOpcode, ...args: SingleBuilderOperand[]): void;
        private operand;
        private get currentLabels();
        label(name: string): void;
        startLabels(): void;
        stopLabels(): void;
    }
}