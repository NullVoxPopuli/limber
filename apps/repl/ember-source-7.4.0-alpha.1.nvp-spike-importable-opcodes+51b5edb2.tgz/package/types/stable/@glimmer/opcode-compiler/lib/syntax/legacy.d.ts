declare module '@glimmer/opcode-compiler/lib/syntax/legacy' {
    /**
     * Fills the numeric lookup table used by templates that still ship a JSON
     * block. Only the legacy template factory calls this, so a build with no JSON
     * blocks does not pull in every op.
     */
    export function ensureLegacyOps(): void;
}