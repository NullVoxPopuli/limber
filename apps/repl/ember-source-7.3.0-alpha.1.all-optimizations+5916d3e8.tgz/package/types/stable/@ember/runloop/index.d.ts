declare module '@ember/runloop' {
    /**
      SPIKE (backburner removal): the run loop is gone. What remains here is
      a dependency-free compatibility surface so the module specifier keeps
      resolving: `run`/`join`/`bind` are plain calls, queues collapse to
      microtasks, and timers are native timers. Rendering is driven by
      `@ember/scheduler`; nothing in the framework schedules through this
      module anymore.

      @module @ember/runloop
      @public
    */
    type AnyFn = (...args: unknown[]) => unknown;
    export interface Timeout {
        kind: "timeout";
        id: ReturnType<typeof setTimeout>;
    }
    export interface Microtask {
        kind: "microtask";
        cancelled: boolean;
    }
    export type Timer = Timeout | Microtask;
    /**
      Runs the passed function immediately. With no run loop, this is a
      plain call.

      @method run
      @for @ember/runloop
      @static
      @public
    */
    export function run(...args: unknown[]): unknown;
    /**
      Runs the passed function immediately, joining any conceptual ongoing
      work. With no run loop, this is a plain call.

      @method join
      @for @ember/runloop
      @static
      @public
    */
    export function join(...args: unknown[]): unknown;
    /**
      Returns a function bound to the given target and arguments. With no
      run loop there is nothing to wrap; this is `Function#bind` with
      string-method resolution.

      @method bind
      @for @ember/runloop
      @static
      @public
    */
    export function bind(...curried: unknown[]): AnyFn;
    /**
      Begins a run loop. With no run loop, this is a no-op.

      @method begin
      @for @ember/runloop
      @static
      @public
    */
    export function begin(): void;
    /**
      Ends a run loop. With no run loop, this is a no-op.

      @method end
      @for @ember/runloop
      @static
      @public
    */
    export function end(): void;
    /**
      Schedules work onto a queue. Queues collapse to the microtask queue:
      work runs after the current synchronous execution, in scheduling
      order.

      @method schedule
      @for @ember/runloop
      @static
      @public
    */
    export function schedule(_queue: string, ...args: unknown[]): Timer;
    /**
      Schedules work onto a queue, coalescing repeat requests for the same
      target and method until the scheduled microtask runs.

      @method scheduleOnce
      @for @ember/runloop
      @static
      @public
    */
    export function scheduleOnce(_queue: string, ...args: unknown[]): Timer;
    /**
      Schedules work to run once, coalescing repeat requests for the same
      target and method.

      @method once
      @for @ember/runloop
      @static
      @public
    */
    export function once(...args: unknown[]): Timer;
    /**
      Runs the passed function in the next task.

      @method next
      @for @ember/runloop
      @static
      @public
    */
    export function next(...args: unknown[]): Timer;
    /**
      Runs the passed function after the given number of milliseconds.

      @method later
      @for @ember/runloop
      @static
      @public
    */
    export function later(...args: unknown[]): Timer;
    /**
      Debounces the passed function by the given number of milliseconds.

      @method debounce
      @for @ember/runloop
      @static
      @public
    */
    export function debounce(...args: unknown[]): Timer;
    /**
      Throttles the passed function to at most once per the given number of
      milliseconds.

      @method throttle
      @for @ember/runloop
      @static
      @public
    */
    export function throttle(...args: unknown[]): Timer;
    /**
      Cancels a timer returned from `later`, `next`, `once`, `schedule`,
      `scheduleOnce`, `debounce`, or `throttle`.

      @method cancel
      @for @ember/runloop
      @static
      @public
    */
    export function cancel(timer?: Timer): boolean;
    export function _getCurrentRunLoop(): null;
    export function _hasScheduledTimers(): boolean;
    export function _cancelTimers(): void;
    export {};
}