declare module 'ember-template-compiler/lib/plugins/assert-against-attrs' {
    import type { ASTPluginBuilder } from "@glimmer/syntax";
    const _default: ASTPluginBuilder;
    export default _default;
}