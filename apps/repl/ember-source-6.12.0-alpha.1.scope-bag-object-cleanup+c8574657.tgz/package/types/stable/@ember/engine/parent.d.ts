declare module '@ember/engine/parent' {
    export * from "@ember/engine/lib/engine-parent";
}