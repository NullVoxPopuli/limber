declare module '@ember/-internals/utils/lib/is_proxy' {
    import type { _ProxyMixin as ProxyMixin } from "@ember/-internals/runtime";
    export function isProxy(value: unknown): value is ProxyMixin<unknown>;
    export function setProxy(object: ProxyMixin<unknown>): void;
}