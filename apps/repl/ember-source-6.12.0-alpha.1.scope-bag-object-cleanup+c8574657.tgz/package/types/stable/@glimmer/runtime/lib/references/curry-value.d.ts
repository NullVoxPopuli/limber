declare module '@glimmer/runtime/lib/references/curry-value' {
    import type { CapturedArguments, ClassicResolver, CurriedType, Nullable, Owner } from "@glimmer/interfaces";
    import type { Reference } from "@glimmer/reference";
    export default function createCurryRef(type: CurriedType, inner: Reference, owner: Owner, args: Nullable<CapturedArguments>, resolver: Nullable<ClassicResolver>, isStrict: boolean): Reference<string | object | null>;
}