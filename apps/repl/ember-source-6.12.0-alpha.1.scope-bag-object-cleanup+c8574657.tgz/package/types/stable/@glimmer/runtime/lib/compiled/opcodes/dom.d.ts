declare module '@glimmer/runtime/lib/compiled/opcodes/dom' {
    import type { Environment, ModifierInstance, UpdatingOpcode, UpdatingVM } from "@glimmer/interfaces";
    import type { Reference } from "@glimmer/reference";
    import type { Tag } from "@glimmer/validator";
    import type { DynamicAttribute } from "@glimmer/runtime/lib/vm/attributes/dynamic";
    export class UpdateModifierOpcode implements UpdatingOpcode {
        private tag;
        private modifier;
        private lastUpdated;
        constructor(tag: Tag, modifier: ModifierInstance);
        evaluate(vm: UpdatingVM): void;
    }
    export class UpdateDynamicModifierOpcode implements UpdatingOpcode {
        private tag;
        private instance;
        private instanceRef;
        private lastUpdated;
        constructor(tag: Tag | null, instance: ModifierInstance | undefined, instanceRef: Reference<ModifierInstance | undefined>);
        evaluate(vm: UpdatingVM): void;
    }
    export class UpdateDynamicAttributeOpcode implements UpdatingOpcode {
        private updateRef;
        constructor(reference: Reference, attribute: DynamicAttribute, env: Environment);
        evaluate(): void;
    }
}