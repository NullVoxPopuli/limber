declare module '@glimmer/runtime/lib/helpers/concat' {
    /**
      Concatenates the given arguments into a string.

      Example:

      ```handlebars
      {{some-component name=(concat firstName " " lastName)}}

      {{! would pass name="<first name value> <last name value>" to the component}}
      ```

      or for angle bracket invocation, you actually don't need concat at all.

      ```handlebars
      <SomeComponent @name="{{firstName}} {{lastName}}" />
      ```

      @public
      @method concat
    */
    export const concat: object;
}