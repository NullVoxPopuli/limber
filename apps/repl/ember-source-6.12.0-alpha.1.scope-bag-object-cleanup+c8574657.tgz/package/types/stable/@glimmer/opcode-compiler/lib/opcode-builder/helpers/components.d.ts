declare module '@glimmer/opcode-compiler/lib/opcode-builder/helpers/components' {
    import type { CapabilityMask, CompilableProgram, CompileTimeComponent, LayoutWithContext, NamedBlocks, Nullable, WireFormat } from "@glimmer/interfaces";
    import type { SavedRegister } from "@glimmer/vm";
    import type { PushExpressionOp, PushStatementOp } from "@glimmer/opcode-compiler/lib/syntax/compilers";
    export const ATTRS_BLOCK = "&attrs";
    interface AnyComponent {
        elementBlock: Nullable<WireFormat.SerializedInlineBlock>;
        positional: WireFormat.Core.Params;
        named: WireFormat.Core.Hash;
        blocks: NamedBlocks;
    }
    export interface DynamicComponent extends AnyComponent {
        definition: WireFormat.Expression;
        atNames: boolean;
        curried: boolean;
    }
    export interface StaticComponent extends AnyComponent {
        capabilities: CapabilityMask;
        layout: CompilableProgram;
    }
    export interface Component extends AnyComponent {
        capabilities: CapabilityMask | true;
        atNames: boolean;
        layout?: CompilableProgram;
    }
    export function InvokeComponent(
        op: PushStatementOp,
        component: CompileTimeComponent,
        _elementBlock: WireFormat.Core.ElementParameters,
        positional: WireFormat.Core.Params,
        named: WireFormat.Core.Hash,
        _blocks: WireFormat.Core.Blocks
    ): void;
    export function InvokeDynamicComponent(
        op: PushStatementOp,
        definition: WireFormat.Core.Expression,
        _elementBlock: WireFormat.Core.ElementParameters,
        positional: WireFormat.Core.Params,
        named: WireFormat.Core.Hash,
        _blocks: WireFormat.Core.Blocks,
        atNames: boolean,
        curried: boolean
    ): void;
    export function InvokeNonStaticComponent(
        op: PushStatementOp,
        { capabilities, elementBlock, positional, named, atNames, blocks: namedBlocks, layout }: Component
    ): void;
    export function WrappedComponent(op: PushStatementOp, layout: LayoutWithContext, attrsBlockNumber: number): void;
    export function invokePreparedComponent(
        op: PushStatementOp,
        hasBlock: boolean,
        bindableBlocks: boolean,
        bindableAtNames: boolean,
        populateLayout?: Nullable<() => void>
    ): void;
    export function InvokeBareComponent(op: PushStatementOp): void;
    export function WithSavedRegister(op: PushExpressionOp, register: SavedRegister, block: () => void): void;
    export {};
}