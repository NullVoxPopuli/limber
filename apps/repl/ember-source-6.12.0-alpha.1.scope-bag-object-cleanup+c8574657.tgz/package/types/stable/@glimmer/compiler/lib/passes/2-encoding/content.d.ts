declare module '@glimmer/compiler/lib/passes/2-encoding/content' {
    import type { WellKnownAttrName, WireFormat } from "@glimmer/interfaces";
    import type { OptionalList } from "@glimmer/compiler/lib/shared/list";
    import type * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    class WireStatements<S extends WireFormat.Statement = WireFormat.Statement> {
        private statements;
        constructor(statements: readonly S[]);
        toArray(): readonly S[];
    }
    export class ContentEncoder {
        list(statements: mir.Statement[]): WireFormat.Statement[];
        content(stmt: mir.Statement): WireFormat.Statement | WireStatements;
        private visitContent;
        Yield({ to, positional }: mir.Yield): WireFormat.Statements.Yield;
        InElement({ guid, insertBefore, destination, block, }: mir.InElement): WireFormat.Statements.InElement;
        InvokeBlock({ head, args, blocks }: mir.InvokeBlock): WireFormat.Statements.Block;
        AppendTrustedHTML({ html }: mir.AppendTrustedHTML): WireFormat.Statements.TrustingAppend;
        AppendTextNode({ text }: mir.AppendTextNode): WireFormat.Statements.Append;
        AppendComment({ value }: mir.AppendComment): WireFormat.Statements.Comment;
        SimpleElement({ tag, params, body, dynamicFeatures }: mir.SimpleElement): WireStatements;
        Component({ tag, params, args, blocks }: mir.Component): WireFormat.Statements.Component;
        ElementParameters({ body }: mir.ElementParameters): OptionalList<WireFormat.ElementParameter>;
        ElementParameter(param: mir.ElementParameter): WireFormat.ElementParameter;
        NamedBlocks({ blocks }: mir.NamedBlocks): WireFormat.Core.Blocks;
        NamedBlock({ name, body, scope }: mir.NamedBlock): WireFormat.Core.NamedBlock;
        If({ condition, block, inverse }: mir.If): WireFormat.Statements.If;
        Each({ value, key, block, inverse }: mir.Each): WireFormat.Statements.Each;
        Let({ positional, block }: mir.Let): WireFormat.Statements.Let;
        WithDynamicVars({ named, block }: mir.WithDynamicVars): WireFormat.Statements.WithDynamicVars;
        InvokeComponent({ definition, args, blocks, }: mir.InvokeComponent): WireFormat.Statements.InvokeComponent;
    }
    export const CONTENT: ContentEncoder;
    export type StaticAttrArgs = [name: string | WellKnownAttrName, value: string, namespace?: string];
    export type DynamicAttrArgs = [
        name: string | WellKnownAttrName,
        value: WireFormat.Expression,
        namespace?: string
    ];
    export {};
}