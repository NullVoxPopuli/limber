declare module '@glimmer/compiler/lib/shared/list' {
    import type { Nullable, PresentArray } from "@glimmer/interfaces";
    export interface OptionalList<T> {
        map<U>(callback: (input: T) => U): MapList<T, U, AnyOptionalList<T>>;
        filter<S extends T>(predicate: (value: T, index: number, array: T[]) => value is S): AnyOptionalList<S>;
        toArray(): T[];
        toPresentArray(): Nullable<PresentArray<T>>;
        into<U, V>(options: {
            ifPresent: (array: PresentList<T>) => U;
            ifEmpty: () => V;
        }): U | V;
    }
    export class PresentList<T> implements OptionalList<T> {
        readonly list: PresentArray<T>;
        constructor(list: PresentArray<T>);
        toArray(): PresentArray<T>;
        map<U>(callback: (input: T) => U): MapList<T, U, PresentList<T>>;
        filter<S extends T>(predicate: (value: T) => value is S): AnyOptionalList<S>;
        toPresentArray(): PresentArray<T>;
        into<U, V>({ ifPresent }: {
            ifPresent: (array: PresentList<T>) => U;
            ifEmpty: () => V;
        }): U | V;
    }
    export class EmptyList<T> implements OptionalList<T> {
        readonly list: T[];
        map<U>(_callback: (input: T) => U): MapList<T, U, EmptyList<T>>;
        filter<S extends T>(_predicate: (value: T) => value is S): AnyOptionalList<S>;
        toArray(): T[];
        toPresentArray(): Nullable<PresentArray<T>>;
        into<U, V>({ ifEmpty }: {
            ifPresent: (array: PresentList<T>) => U;
            ifEmpty: () => V;
        }): U | V;
    }
    export function OptionalList<T>(value: readonly T[]): AnyOptionalList<T>;
    export type AnyOptionalList<T> = (PresentList<T> | EmptyList<T>) & OptionalList<T>;
    export type MapList<T, U, L extends OptionalList<T>> = L extends PresentList<T> ? PresentList<U> : L extends EmptyList<T> ? EmptyList<U> : never;
}