declare module '@glimmer/compiler/lib/passes/2-encoding/expressions' {
    import type { PresentArray, WireFormat } from "@glimmer/interfaces";
    import type { ASTv2 } from "@glimmer/syntax";
    import type * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export type HashPair = [string, WireFormat.Expression];
    export class ExpressionEncoder {
        expr(expr: mir.ExpressionNode): WireFormat.Expression;
        Literal({ value, }: ASTv2.LiteralExpression): WireFormat.Expressions.Value | WireFormat.Expressions.Undefined;
        Missing(): undefined;
        HasBlock({ symbol }: mir.HasBlock): WireFormat.Expressions.HasBlock;
        HasBlockParams({ symbol }: mir.HasBlockParams): WireFormat.Expressions.HasBlockParams;
        Curry({ definition, curriedType, args }: mir.Curry): WireFormat.Expressions.Curry;
        Local({ isTemplateLocal, symbol, }: ASTv2.LocalVarReference): WireFormat.Expressions.GetSymbol | WireFormat.Expressions.GetLexicalSymbol;
        Keyword({ symbol }: ASTv2.KeywordExpression): WireFormat.Expressions.GetStrictFree;
        PathExpression({ head, tail }: mir.PathExpression): WireFormat.Expressions.GetPath;
        InterpolateExpression({ parts }: mir.InterpolateExpression): WireFormat.Expressions.Concat;
        CallExpression({ callee, args }: mir.CallExpression): WireFormat.Expressions.Helper;
        Tail({ members }: mir.Tail): PresentArray<string>;
        Args({ positional, named }: mir.Args): WireFormat.Core.Args;
        Positional({ list }: mir.Positional): WireFormat.Core.Params;
        NamedArgument({ key, value }: mir.NamedArgument): HashPair;
        NamedArguments({ entries: pairs }: mir.NamedArguments): WireFormat.Core.Hash;
        Not({ value }: mir.Not): WireFormat.Expressions.Not;
        IfInline({ condition, truthy, falsy }: mir.IfInline): WireFormat.Expressions.IfInline;
        GetDynamicVar({ name }: mir.GetDynamicVar): WireFormat.Expressions.GetDynamicVar;
        Log({ positional }: mir.Log): WireFormat.Expressions.Log;
    }
    export const EXPR: ExpressionEncoder;
}