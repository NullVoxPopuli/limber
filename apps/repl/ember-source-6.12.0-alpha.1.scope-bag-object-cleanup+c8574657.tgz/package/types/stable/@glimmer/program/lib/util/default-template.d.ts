declare module '@glimmer/program/lib/util/default-template' {
    import type { SerializedTemplateWithLazyBlock } from "@glimmer/interfaces";
    export const DEFAULT_TEMPLATE: SerializedTemplateWithLazyBlock;
}