declare module '@glimmer/compiler/lib/codegen/generate' {
    /**
     * EXPERIMENTAL: compile a strict-mode template's ASTv1 directly to JavaScript
     * that builds and updates DOM, using the helpers from `@glimmer/dom`.
     *
     * There is no wire format and no VM bytecode: static markup becomes an HTML
     * string that is cloned, and each dynamic part of the template becomes one
     * call to a runtime helper (with thunks for the values it reads).
     *
     * This module only depends on AST *types*, so it can be used with any
     * `preprocess` (e.g. the one exported by ember-template-compiler).
     */
    import type * as ASTv1 from "@glimmer/syntax/lib/v1/nodes-v1";
    export interface ImportInfo {
        module: string;
        name: string;
    }
    export interface GenerateOptions {
        /**
         * Is `name` a JavaScript binding that is in scope where the template is
         * defined? (strict mode: this is the only way to reference values)
         */
        isLexical(name: string): boolean;
        /**
         * If `name` is bound by an import, where it was imported from. Used to
         * specialize well-known helpers and modifiers (`on`, `fn`, `hash`, ...).
         */
        importOf?(name: string): ImportInfo | undefined;
        /**
         * Returns the identifier to use for a runtime helper from `@glimmer/dom`.
         */
        runtime(name: string): string;
        /**
         * Returns the identifier to use for a named import (used for built-in
         * keywords that are auto-imported but not specialized).
         */
        importBinding(module: string, name: string): string;
        /**
         * Prefix for generated identifiers (including hoisted declarations), so
         * that several templates can be compiled into one module.
         */
        prefix?: string;
    }
    export interface Generated {
        /**
         * Module-level declarations (static HTML) that the expression references.
         */
        hoisted: string[];
        /**
         * An expression that evaluates to the compiled template.
         */
        expression: string;
    }
    export class CodegenError extends Error {
        constructor(message: string, node?: {
            loc?: unknown;
        });
    }
    export function generate(ast: ASTv1.Template, options: GenerateOptions): Generated;
}