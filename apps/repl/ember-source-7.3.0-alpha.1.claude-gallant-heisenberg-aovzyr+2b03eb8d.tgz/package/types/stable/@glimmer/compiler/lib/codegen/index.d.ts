declare module '@glimmer/compiler/lib/codegen' {
    import type * as ASTv1 from "@glimmer/syntax/lib/v1/nodes-v1";
    import type { Generated, ImportInfo } from "@glimmer/compiler/lib/codegen/generate";
    export { codegenBabelPlugin, type CodegenBabelPluginOptions } from "@glimmer/compiler/lib/codegen/babel-plugin";
    export { CodegenError, generate, type GenerateOptions, type Generated, type ImportInfo, } from "@glimmer/compiler/lib/codegen/generate";
    export interface CompileToDOMOptions {
        /**
         * The JavaScript bindings that are in scope for the template.
         */
        lexicalScope?: (name: string) => boolean;
        /**
         * Where (some of) those bindings were imported from.
         */
        importOf?: (name: string) => ImportInfo | undefined;
        /**
         * Where the runtime helpers are imported from.
         */
        runtimeModule?: string;
    }
    /**
     * Collects the imports used by generated code.
     */
    export class ImportCollector {
        #private;
        readonly runtimeModule: string;
        constructor(runtimeModule?: string);
        runtime: (name: string) => string;
        importBinding: (module: string, name: string) => string;
        add(module: string, name: string, local: string): string;
        entries(): Array<[module: string, names: Map<string, string>]>;
        toString(): string;
    }
    export function parse(source: string): ASTv1.Template;
    /**
     * EXPERIMENTAL: compile a strict-mode template to an ES module whose default
     * export is the compiled template (usable as a template-only component).
     */
    export function compileToDOM(source: string, options?: CompileToDOMOptions): string;
    export function generateFor(
     ast: ASTv1.Template,
     options: CompileToDOMOptions,
     imports: ImportCollector
    ): Generated;
}