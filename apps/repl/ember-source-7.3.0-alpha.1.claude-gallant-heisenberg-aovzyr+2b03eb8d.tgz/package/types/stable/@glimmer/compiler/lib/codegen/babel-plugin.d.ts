declare module '@glimmer/compiler/lib/codegen/babel-plugin' {
    export interface CodegenBabelPluginOptions {
        /**
         * Parses a template into ASTv1. (`preprocess` from `@glimmer/syntax`, or
         * `_preprocess` from `ember-source/ember-template-compiler`)
         */
        preprocess: (source: string, options: {
            strictMode: boolean;
        }) => unknown;
        /**
         * Where the runtime helpers are imported from.
         */
        runtimeModule?: string;
    }
    interface State {
        codegen: {
            imports: Map<string, Map<string, string>>;
            hoisted: string[];
            templates: number;
        };
    }
    /**
     * EXPERIMENTAL: compiles `template(...)` calls from strict-mode (gjs/gts)
     * modules directly to DOM operations, in place.
     *
     * Template-scoped values are resolved by JavaScript itself: the compiled
     * template is emitted where the `template()` call was, so it simply closes
     * over the module's bindings.
     */
    export function codegenBabelPlugin(babel: any, options: CodegenBabelPluginOptions): {
        name: string;
        visitor: {
            Program: {
                enter(_path: any, state: State): void;
                exit(path: any, state: State): void;
            };
            CallExpression(path: any, state: State): void;
        };
    };
    export {};
}