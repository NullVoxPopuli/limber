declare module '@glimmer/dom/lib/managers' {
    import type { CapturedArguments } from "@glimmer/interfaces";
    import type { Block, Thunk } from "@glimmer/dom/lib/core";
    export type Named = Record<string, Thunk>;
    /**
     * Adapt thunks to the references that helper/modifier/component managers
     * expect. This is the only place the compiled-template world touches
     * references.
     */
    export function capture(named: Named | null, positional: Thunk[] | null): CapturedArguments;
    /**
     * A helper invocation with a statically known definition
     * (usually an import). Returns a thunk for the helper's current value.
     */
    export function helper(
     b: Block,
     definition: object,
     positional: Thunk[] | null,
     named: Named | null
    ): Thunk;
    /**
     * A helper invocation whose definition can change, like `(this.format x)`.
     */
    export function helperDyn(
     b: Block,
     definition: Thunk,
     positional: Thunk[] | null,
     named: Named | null
    ): Thunk;
    /**
     * Any modifier other than `{{on}}`, which is specialized.
     */
    export function modifier(
     b: Block,
     element: Element,
     definition: object,
     positional: Thunk[] | null,
     named: Named | null
    ): void;
}