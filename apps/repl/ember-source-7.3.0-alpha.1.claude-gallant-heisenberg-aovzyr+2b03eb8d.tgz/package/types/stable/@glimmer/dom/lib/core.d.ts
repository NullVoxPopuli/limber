declare module '@glimmer/dom/lib/core' {
    /**
     * A lazily-evaluated value. Compiled templates pass every dynamic value
     * around as a thunk, so that reading it happens inside whichever tracking
     * frame (cache) is consuming it.
     */
    export type Thunk<T = unknown> = () => T;
    export type Updater = () => void;
    /**
     * A render function for a block of template content.
     *
     * It receives the block that owns the content (for registering updaters and
     * destructors), plus one thunk per block param, and returns the DOM it
     * created (usually a DocumentFragment).
     */
    export type BlockFn = (b: Block, ...params: Thunk[]) => Node;
    export type AttrsFn = (b: Block, element: Element) => void;
    export type Blocks = Partial<Record<string, BlockFn>>;
    /**
     * Everything a component's template can see about its invocation.
     */
    export interface Ctx {
        self: unknown;
        args: Record<string, unknown>;
        blocks: Blocks | null;
        attrs: AttrsFn | null;
    }
    /**
     * Shared state for one render tree (one `renderComponent` call).
     */
    export class Root {
        #private;
        readonly owner: object;
        readonly document: Document;
        constructor(owner: object, document: Document);
        /**
         * Schedule work that must happen after DOM is inserted
         * (modifier install/update, component didCreate hooks).
         */
        schedule(fn: () => void): void;
        flush(): void;
    }
    /**
     * The unit of ownership: a block owns the updaters and destructors for a
     * contiguous region of DOM. Structural helpers (`when`, `each`, components,
     * yields) create child blocks, and are responsible for updating them.
     *
     * This is the replacement for the UpdatingVM's opcode tree: rather than
     * recording opcodes during an initial render, compiled templates register
     * closures directly.
     */
    export class Block {
        readonly root: Root;
        readonly updaters: Updater[];
        constructor(root: Root, parent: Block | null);
        update(): void;
    }
    /**
     * A region of DOM owned by a child block, delimited by two empty text nodes.
     * Empty text nodes are invisible in serialized HTML, and give us stable
     * boundaries even when the content at either edge is itself dynamic.
     */
    export interface Mounted {
        b: Block;
        start: Node;
        end: Node;
    }
    export function marker(root: Root): Text;
    /**
     * Create a child block, render into it, and insert the result before `before`.
     */
    export function mount(parent: Block, before: Node, render: (b: Block) => Node): Mounted;
    export function unmount(m: Mounted): void;
    export function removeRange(first: Node, last: Node): void;
    export function moveRange(m: Mounted, before: Node): void;
    /**
     * Static markup for one block of a template. Parsed once (lazily), then
     * cloned for every render. This is where most of the size savings come from:
     * static content costs about what its HTML text costs.
     */
    export interface StaticHTML {
        markup: string;
        parsed: HTMLTemplateElement | null;
    }
    export function html(markup: string): StaticHTML;
    export function clone(b: Block, t: StaticHTML): DocumentFragment;
    /**
     * Walk to a node by child indexes. Compiled templates resolve every node they
     * need right after cloning, before any helper mutates the DOM.
     */
    export function at(node: Node, ...path: number[]): Node;
    export type RenderFn = (b: Block, ctx: Ctx) => Node;
    /**
     * A compiled template. It doubles as a template-only component definition.
     */
    export class Template {
        readonly render: RenderFn;
        constructor(render: RenderFn);
        toString(): string;
    }
    export function template(render: RenderFn): Template;
    /**
     * The equivalent of `setComponentTemplate` for compiled templates.
     */
    export function setTemplate<T extends object>(definition: T, t: Template): T;
    export function templateFor(definition: object): Template | undefined;
}