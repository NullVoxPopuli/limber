declare module '@glimmer/dom/lib/attributes' {
    import type { Block, Ctx, Thunk } from "@glimmer/dom/lib/core";
    export function attr(b: Block, element: Element, name: string, value: unknown): void;
    /**
     * `...attributes`
     */
    export function splat(b: Block, element: Element, ctx: Ctx): void;
    /**
     * The `{{on}}` modifier, specialized at compile time.
     *
     * The handler is read when the event fires, so changing it never requires
     * re-binding the listener.
     */
    export function listen(
     b: Block,
     element: Element,
     eventName: string,
     handler: Thunk,
     options?: AddEventListenerOptions
    ): void;
}