declare module '@glimmer/dom/lib/control-flow' {
    import type { Block, BlockFn, Ctx, Thunk } from "@glimmer/dom/lib/core";
    /**
     * `{{#if}}` / `{{#unless}}` (the compiler negates the condition for unless).
     */
    export function when(
     b: Block,
     anchor: Node,
     condition: Thunk<boolean>,
     consequent: BlockFn,
     alternate?: BlockFn
    ): void;
    /**
     * `{{#each}}`, keyed by `key` (`@identity` by default).
     */
    export function each(
     b: Block,
     anchor: Node,
     list: Thunk,
     key: string | null,
     item: BlockFn,
     inverse?: BlockFn
    ): void;
    /**
     * `{{yield}}` / `{{yield to="name"}}`
     */
    export function yieldTo(b: Block, anchor: Node, ctx: Ctx, name: string, params: Thunk[]): void;
    /**
     * `{{#let}}` (bindings are created by the compiler via `memo`)
     */
    export function scope(b: Block, anchor: Node, fn: BlockFn): void;
    /**
     * `{{#in-element}}`. By default the destination's content is replaced;
     * pass `insertBefore=null` to append.
     */
    export function inElement(b: Block, destination: Thunk, append: boolean, fn: BlockFn): void;
}