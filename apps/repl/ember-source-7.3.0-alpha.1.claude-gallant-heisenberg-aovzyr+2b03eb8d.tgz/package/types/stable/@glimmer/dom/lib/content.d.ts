declare module '@glimmer/dom/lib/content' {
    import type { Block, Thunk } from "@glimmer/dom/lib/core";
    import type { Named } from "@glimmer/dom/lib/managers";
    /**
     * `{{x}}` where `x` is a bare lexical identifier. It may be a helper, which
     * is invoked with no arguments.
     */
    export const MAY_CALL = 1;
    /**
     * `{{{x}}}`
     */
    export const TRUSTING = 2;
    /**
     * `{{value}}` in content position. The value's type decides what is rendered
     * (text, trusted HTML, a DOM node, or a component), and can change over time.
     */
    export function content(b: Block, anchor: Node, fn: Thunk, flags?: number): void;
    /**
     * `{{foo a b=c}}`: invokes `foo` as a component or as a helper, depending
     * on what it is.
     */
    export function appendCall(
     b: Block,
     anchor: Node,
     definition: unknown,
     isStatic: boolean,
     positional: Thunk[] | null,
     named: Named | null,
     flags?: number
    ): void;
}