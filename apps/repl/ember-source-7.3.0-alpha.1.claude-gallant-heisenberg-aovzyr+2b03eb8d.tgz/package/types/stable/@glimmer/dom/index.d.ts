declare module '@glimmer/dom' {
    /**
     * EXPERIMENTAL
     *
     * Runtime helpers for strict-mode templates that are compiled directly to
     * DOM operations (see `compileToDOM` in `@glimmer/compiler`), instead of to
     * the wire format and then to VM bytecode.
     *
     * Each dynamic part of a template becomes one call to one of these helpers;
     * the helpers own all of the behavior, so compiled output stays small and
     * apps only pay for the helpers their templates use.
     */
    export type { AttrsFn, Block, BlockFn, Blocks, Ctx, Thunk } from "@glimmer/dom/lib/core";
    export { at, clone, html, setTemplate, template, Template } from "@glimmer/dom/lib/core";
    export { attr, listen, splat } from "@glimmer/dom/lib/attributes";
    export { appendCall, content, MAY_CALL, TRUSTING } from "@glimmer/dom/lib/content";
    export { each, inElement, scope, when, yieldTo } from "@glimmer/dom/lib/control-flow";
    export { curry, invoke, invokeDyn, setVMFallback } from "@glimmer/dom/lib/invoke";
    export { helper, helperDyn, modifier } from "@glimmer/dom/lib/managers";
    export { renderComponent, type RenderResult } from "@glimmer/dom/lib/render";
    export { and, bool, entries, get, getPath, hasBlock, hasBlockParams, log, memo, or, str, } from "@glimmer/dom/lib/values";
}