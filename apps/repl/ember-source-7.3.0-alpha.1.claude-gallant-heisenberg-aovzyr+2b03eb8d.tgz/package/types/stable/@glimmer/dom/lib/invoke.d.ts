declare module '@glimmer/dom/lib/invoke' {
    import type { AttrsFn, Block, Blocks, Thunk } from "@glimmer/dom/lib/core";
    import type { Named } from "@glimmer/dom/lib/managers";
    /**
     * The result of `(component Foo bar=1)`.
     */
    export class Curried {
        readonly definition: object;
        readonly named: Named;
        constructor(definition: object, named: Named);
    }
    export function curry(definition: unknown, named: Named | null): Curried | null;
    export function isComponentDefinition(value: unknown): value is object;
    /**
     * Renders components that were not compiled with this compiler (e.g. from
     * addons) via the VM. Registered by the Ember integration (see `render.ts`).
     */
    export type VMFallback = (definition: object, into: Element, owner: object, args: Record<string, unknown>) => {
        destroy(): void;
    };
    export function setVMFallback(fallback: VMFallback): void;
    /**
     * Create a component and render its template into `b`.
     */
    export function instantiate(
     b: Block,
     definition: object,
     named: Named,
     blocks: Blocks | null,
     attrs: AttrsFn | null
    ): Node;
    /**
     * `<Foo />` where `Foo` is statically known (an import, or a local).
     */
    export function invoke(
     b: Block,
     anchor: Node,
     definition: object,
     named: Named,
     blocks: Blocks | null,
     attrs: AttrsFn | null
    ): void;
    /**
     * `<this.Foo />`, `<@foo />`, `{{component this.foo}}`, `<item.Foo />` ...
     */
    export function invokeDyn(
     b: Block,
     anchor: Node,
     definition: Thunk,
     named: Named,
     blocks: Blocks | null,
     attrs: AttrsFn | null
    ): void;
}