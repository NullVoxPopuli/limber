declare module 'ember-testing/lib/public-api' {
    export { default as Test } from "ember-testing/lib/test";
    export { default as Adapter } from "ember-testing/lib/adapters/adapter";
}