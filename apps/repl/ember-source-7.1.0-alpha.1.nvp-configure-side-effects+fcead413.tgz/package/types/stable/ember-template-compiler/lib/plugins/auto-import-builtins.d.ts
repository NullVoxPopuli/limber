declare module 'ember-template-compiler/lib/plugins/auto-import-builtins' {
    import type { ASTPluginBuilder } from "@glimmer/syntax";
    const _default: ASTPluginBuilder;
    export default _default;
}