declare module '@glimmer/runtime/lib/vm/render-result' {
    import type { AppendingBlock, Environment, RenderResult, SimpleNode, UpdatingOpcode } from "@glimmer/interfaces";
    export default class RenderResultImpl implements RenderResult {
        env: Environment;
        private updating;
        private bounds;
        readonly drop: object;
        constructor(env: Environment, updating: UpdatingOpcode[], bounds: AppendingBlock, drop: object);
        rerender({ alwaysRevalidate }?: {
            alwaysRevalidate?: false;
        }): void;
        parentNode(): SimpleNode;
        firstNode(): SimpleNode;
        lastNode(): SimpleNode;
        handleException(): void;
    }
}