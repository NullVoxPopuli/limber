declare module '@glimmer/runtime/lib/bounds' {
    import type { Bounds, Cursor, Nullable, SimpleNode } from "@glimmer/interfaces";
    export class CursorImpl implements Cursor {
        element: SimpleNode;
        nextSibling: Nullable<SimpleNode>;
        constructor(element: SimpleNode, nextSibling: Nullable<SimpleNode>);
    }
    export type DestroyableBounds = Bounds;
    export class ConcreteBounds implements Bounds {
        private parent;
        private first;
        private last;
        constructor(parent: SimpleNode, first: SimpleNode, last: SimpleNode);
        parentNode(): SimpleNode;
        firstNode(): SimpleNode;
        lastNode(): SimpleNode;
    }
    export function move(bounds: Bounds, reference: Nullable<SimpleNode>): Nullable<SimpleNode>;
    export function clear(bounds: Bounds): Nullable<SimpleNode>;
}