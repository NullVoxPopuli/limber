export declare function isString(x: unknown): x is string;
export declare function lte(a: number, b: number): boolean;
//# sourceMappingURL=utils.d.ts.map